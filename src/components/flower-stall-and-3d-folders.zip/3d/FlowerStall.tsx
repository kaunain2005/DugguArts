"use client";

import React, { useState, useCallback, useEffect, useId, useMemo } from "react";
import { cn } from "@/lib/utils";
import { RoseBouquet } from "@/components/flower-stall/flowers/RoseBouquet";
import { SunflowerBouquet } from "@/components/flower-stall/flowers/SunflowerBouquet";
import { TulipBouquet } from "@/components/flower-stall/flowers/TulipBouquet";
import { DaisyBouquet } from "@/components/flower-stall/flowers/DaisyBouquet";
import { LavenderBouquet } from "@/components/flower-stall/flowers/LavenderBouquet";
import { MixedBouquet } from "@/components/flower-stall/flowers/MixedBouquet";
import { FlowerFocusedView } from "@/components/flower-stall/FlowerFocusedView";

interface FlowerArrangement {
  id: string;
  name: string;
  position: {
    x: number;
    y: number;
    rotation: number;
    scale: number;
  };
  idPrefix: string;
}

interface FlowerStallProps {
  className?: string;
}

export function FlowerStall({ className }: FlowerStallProps) {
  const [hoveredId, setHoveredId] = useState<string | null>(null);
  const [focusedArrangement, setFocusedArrangement] = useState<FlowerArrangement | null>(null);
  const [focusedKey, setFocusedKey] = useState<number>(0);

  // Generate stable unique IDs for this instance
  const instanceId = useId();
  const defsIdPrefix = useMemo(() => `${instanceId}-defs`, [instanceId]);

  const arrangements: FlowerArrangement[] = useMemo(() => [
    {
      id: "rose",
      name: "Pink Rose Bouquet",
      position: { x: 180, y: 300, rotation: -5, scale: 1 },
      idPrefix: `${defsIdPrefix}-rose`,
    },
    {
      id: "sunflower",
      name: "Sunflower Bouquet",
      position: { x: 400, y: 300, rotation: 5, scale: 1 },
      idPrefix: `${defsIdPrefix}-sunflower`,
    },
    {
      id: "tulip",
      name: "Tulip Bouquet",
      position: { x: 580, y: 300, rotation: -3, scale: 1 },
      idPrefix: `${defsIdPrefix}-tulip`,
    },
    {
      id: "daisy",
      name: "Daisy Bouquet",
      position: { x: 180, y: 520, rotation: -3, scale: 1 },
      idPrefix: `${defsIdPrefix}-daisy`,
    },
    {
      id: "lavender",
      name: "Lavender Bouquet",
      position: { x: 400, y: 520, rotation: 3, scale: 1 },
      idPrefix: `${defsIdPrefix}-lavender`,
    },
    {
      id: "mixed",
      name: "Mixed Bouquet",
      position: { x: 580, y: 520, rotation: -3, scale: 1 },
      idPrefix: `${defsIdPrefix}-mixed`,
    },
  ], [defsIdPrefix]);

  const handleCloseFocus = useCallback(() => {
    setFocusedArrangement(null);
    document.body.style.overflow = '';
  }, []);

  const handleBackdropClick = useCallback(() => {
    setFocusedArrangement(null);
    document.body.style.overflow = '';
  }, []);

  const handleKeyDown = useCallback((e: React.KeyboardEvent) => {
    if (e.key === 'Escape' && focusedArrangement) {
      setFocusedArrangement(null);
      document.body.style.overflow = '';
    }
  }, [focusedArrangement]);

  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if (e.key === 'Escape' && focusedArrangement) {
        setFocusedArrangement(null);
        document.body.style.overflow = '';
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, [focusedArrangement]);

  // Render bouquet component based on arrangement
  const renderBouquet = (arr: FlowerArrangement, size = 280) => {
    switch (arr.id) {
      case 'rose':
        return <RoseBouquet key={arr.id} size={size} idPrefix={arr.idPrefix} />;
      case 'sunflower':
        return <SunflowerBouquet key={arr.id} size={size} idPrefix={arr.idPrefix} />;
      case 'tulip':
        return <TulipBouquet key={arr.id} size={size} idPrefix={arr.idPrefix} />;
      case 'daisy':
        return <DaisyBouquet key={arr.id} size={size} idPrefix={arr.idPrefix} />;
      case 'lavender':
        return <LavenderBouquet key={arr.id} size={size} idPrefix={arr.idPrefix} />;
      case 'mixed':
        return <MixedBouquet key={arr.id} size={size} idPrefix={arr.idPrefix} />;
      default:
        return null;
    }
  };

  return (
    <div className={cn("w-full max-w-[700px] mx-auto", className)}>
      <svg
        viewBox="0 0 700 650"
        xmlns="http://www.w3.org/2000/svg"
        className="w-full h-auto overflow-visible"
        role="img"
        aria-label="Illustrated handmade flower shop stall"
        onKeyDown={handleKeyDown}
      >
        <defs>
          {/* Shared gradients and filters for all bouquets */}
          <linearGradient id={`${defsIdPrefix}-wood`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#B97848" />
            <stop offset="100%" stopColor="#87502F" />
          </linearGradient>

          <linearGradient id={`${defsIdPrefix}-roof`} x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#8ACB9B" />
            <stop offset="100%" stopColor="#46996D" />
          </linearGradient>

          <filter id={`${defsIdPrefix}-flowerShadow`} x="-40%" y="-40%" width="180%" height="180%">
            <feDropShadow dx="0" dy="7" stdDeviation="5" floodColor="#60452E" floodOpacity=".22" />
          </filter>

          {/* Rose gradients */}
          <linearGradient id={`${defsIdPrefix}-rose-petalOuterGrad`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#F5C6D6" /><stop offset="50%" stopColor="#E9A8B8" /><stop offset="100%" stopColor="#D48A9E" />
          </linearGradient>
          <linearGradient id={`${defsIdPrefix}-rose-petalMiddleGrad`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#F8D7E3" /><stop offset="50%" stopColor="#ECB8C8" /><stop offset="100%" stopColor="#E09AA8" />
          </linearGradient>
          <linearGradient id={`${defsIdPrefix}-rose-petalInnerGrad`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FCE4EC" /><stop offset="50%" stopColor="#F5C6D6" /><stop offset="100%" stopColor="#E9A8B8" />
          </linearGradient>
          <linearGradient id={`${defsIdPrefix}-rose-petalBudGrad`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FFF0F5" /><stop offset="50%" stopColor="#FCE4EC" /><stop offset="100%" stopColor="#F5C6D6" />
          </linearGradient>
          <radialGradient id={`${defsIdPrefix}-rose-centreGrad`} cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#FFE082" /><stop offset="40%" stopColor="#FFD54F" /><stop offset="70%" stopColor="#F9A825" /><stop offset="100%" stopColor="#F57F17" />
          </radialGradient>
          <radialGradient id={`${defsIdPrefix}-rose-centreInnerGrad`} cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#FFF9C4" /><stop offset="50%" stopColor="#FFF59D" /><stop offset="100%" stopColor="#FDD835" />
          </radialGradient>

          {/* Sunflower gradients */}
          <linearGradient id={`${defsIdPrefix}-sunflower-petalMainGrad`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FFEB3B" /><stop offset="40%" stopColor="#FFD700" /><stop offset="70%" stopColor="#FFC107" /><stop offset="100%" stopColor="#FFA000" />
          </linearGradient>
          <linearGradient id={`${defsIdPrefix}-sunflower-petalBackGrad`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FFD600" /><stop offset="50%" stopColor="#FFC107" /><stop offset="100%" stopColor="#FFA000" />
          </linearGradient>
          <radialGradient id={`${defsIdPrefix}-sunflower-centreGrad`} cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#3E2723" /><stop offset="30%" stopColor="#4E342E" /><stop offset="60%" stopColor="#3E2723" /><stop offset="100%" stopColor="#212121" />
          </radialGradient>
          <radialGradient id={`${defsIdPrefix}-sunflower-centreHighlightGrad`} cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#5D4037" /><stop offset="50%" stopColor="#4E342E" /><stop offset="100%" stopColor="#3E2723" />
          </radialGradient>

          {/* Tulip gradients */}
          <linearGradient id={`${defsIdPrefix}-tulip-petalMainGrad`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FF69B4" /><stop offset="40%" stopColor="#FF69B4" /><stop offset="70%" stopColor="#FF1493" /><stop offset="100%" stopColor="#C71585" />
          </linearGradient>

          {/* Daisy gradients */}
          <linearGradient id={`${defsIdPrefix}-daisy-petalMainGrad`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FFFFFF" /><stop offset="50%" stopColor="#F8F8F8" /><stop offset="100%" stopColor="#F0F0F0" />
          </linearGradient>
          <radialGradient id={`${defsIdPrefix}-daisy-centreGrad`} cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#FFEB3B" /><stop offset="50%" stopColor="#FFD700" /><stop offset="100%" stopColor="#FFD700" />
          </radialGradient>

          {/* Lavender gradients */}
          <linearGradient id={`${defsIdPrefix}-lavender-sprigMainGrad`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#E6E6FA" /><stop offset="40%" stopColor="#D8BFD8" /><stop offset="70%" stopColor="#DDA0DD" /><stop offset="100%" stopColor="#BA55D3" />
          </linearGradient>
          <radialGradient id={`${defsIdPrefix}-lavender-centreGrad`} cx="50%" cy="50%" r="50%">
            <stop offset="0%" stopColor="#E6E6FA" /><stop offset="50%" stopColor="#D8BFD8" /><stop offset="100%" stopColor="#BA55D3" />
          </radialGradient>

          {/* Mixed gradients */}
          <linearGradient id={`${defsIdPrefix}-mixed-petalMainGrad`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FF6B6B" /><stop offset="40%" stopColor="#FF6B6B" /><stop offset="70%" stopColor="#FF4757" /><stop offset="100%" stopColor="#C44569" />
          </linearGradient>

          {/* Shared gradients */}
          <linearGradient id={`${defsIdPrefix}-stemGrad`} x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#4A7C59" /><stop offset="50%" stopColor="#3A6B3A" /><stop offset="100%" stopColor="#2E5D2E" />
          </linearGradient>
          <linearGradient id={`${defsIdPrefix}-leafGrad1`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#6BA571" /><stop offset="50%" stopColor="#5A925E" /><stop offset="100%" stopColor="#4A7C59" />
          </linearGradient>
          <linearGradient id={`${defsIdPrefix}-leafGrad2`} x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#7CB87E" /><stop offset="50%" stopColor="#6BA571" /><stop offset="100%" stopColor="#5A925E" />
          </linearGradient>

          {/* Shared filters */}
          <filter id={`${defsIdPrefix}-dropShadow`} x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="3" /><feOffset dx="2" dy="3" /><feComponentTransfer><feFuncA type="table" tableValues="0 0.3" /></feComponentTransfer><feBlend in="SourceGraphic" mode="normal" />
          </filter>
          <filter id={`${defsIdPrefix}-dropShadowHover`} x="-20%" y="-20%" width="140%" height="140%">
            <feGaussianBlur stdDeviation="5" /><feOffset dx="3" dy="5" /><feComponentTransfer><feFuncA type="table" tableValues="0 0.5" /></feComponentTransfer><feBlend in="SourceGraphic" mode="normal" />
          </filter>
          <filter id={`${defsIdPrefix}-innerShadow`} x="-20%" y="-20%" width="140%" height="140%">
            <feOffset dx="0" dy="1" /><feGaussianBlur stdDeviation="2" /><feComponentTransfer><feFuncA type="table" tableValues="0 0.2" /></feComponentTransfer><feBlend in="SourceGraphic" mode="normal" />
          </filter>

          {/* Petal texture pattern */}
          <pattern id={`${defsIdPrefix}-petalTexture`} patternUnits="userSpaceOnUse" width="4" height="4">
            <circle cx="2" cy="2" r="0.5" fill="rgba(255,255,255,0.1)" />
          </pattern>
        </defs>

        <style>{`
      .flower-arrangement {
        transform-box: fill-box;
        transform-origin: center bottom;
        transform-style: preserve-3d;
        cursor: pointer;
        transition: transform 650ms cubic-bezier(0.16, 1, 0.3, 1), filter 650ms ease;
        filter: drop-shadow(0px 4px 3px rgba(50, 35, 25, 0.12));
      }
      .flower-arrangement:hover, .flower-arrangement:focus-visible {
        transform: perspective(900px) translate3d(0, -22px, 35px) scale(1.16) rotateY(-9deg);
        filter: drop-shadow(0px 18px 14px rgba(50, 35, 25, 0.28));
      }
      .flower-arrangement:focus-visible { outline: none; }
      @media (hover: none) { .flower-arrangement:active { transform: translateY(-12px) scale(1.08); } }
      @media (prefers-reduced-motion: reduce) { .flower-arrangement { transition: none; } }
    `}</style>

        {/* Stall roof */}
        <g filter={`url(#${defsIdPrefix}-flowerShadow)`}>
          <path d="M70 150 L350 35 L630 150 Z" fill="#4B8F68" stroke="#315F48" strokeWidth="7" strokeLinejoin="round" />
          <path d="M83 145 L350 53 L617 145" fill="none" stroke="#B8E0BC" strokeWidth="4" />
          <path
            d="M80 145 H620 V174 C620 207 585 207 580 178 C575 212 535 212 530 178 C525 212 485 212 480 178 C475 212 435 212 430 178 C425 212 385 212 380 178 C375 212 335 212 330 178 C325 212 285 212 280 178 C275 212 235 212 230 178 C225 212 185 212 180 178 C175 212 135 212 130 178 C125 212 85 212 80 174 Z"
            fill={`url(#${defsIdPrefix}-roof)`} stroke="#315F48" strokeWidth="5" strokeLinejoin="round"
          />
        </g>

        {/* Stall supports */}
        <g stroke="#75452D" strokeWidth="13" fill="none">
          <path d="M112 192 V495" /><path d="M588 192 V495" />
        </g>
        <g stroke="#D19A65" strokeWidth="3" opacity=".7">
          <path d="M112 195 V485" /><path d="M588 195 V485" />
        </g>

        {/* Back wall and counter */}
        <g filter={`url(#${defsIdPrefix}-flowerShadow)`}>
          <rect x="85" y="405" width="530" height="145" rx="5" fill={`url(#${defsIdPrefix}-wood)`} stroke="#704229" strokeWidth="6" />
          <path d="M85 450 H615 M85 500 H615" stroke="#714329" strokeWidth="4" />
          <path d="M210 405 V550 M350 405 V550 M490 405 V550" stroke="#75452D" strokeWidth="3" />
          <path d="M70 410 H630 V432 H70 Z" fill="#C68A54" stroke="#75452D" strokeWidth="5" />
        </g>

        {/* Arrangements - Row 1 (y=300) */}
        <g className="flower-arrangement" tabIndex={0} transform="translate(180 300) rotate(-5)" onMouseEnter={() => setHoveredId("rose")} onMouseLeave={() => setHoveredId(null)}>
          {renderBouquet(arrangements[0])}
        </g>
        <g className="flower-arrangement" tabIndex={0} transform="translate(400 300) rotate(5)" onMouseEnter={() => setHoveredId("sunflower")} onMouseLeave={() => setHoveredId(null)}>
          {renderBouquet(arrangements[1])}
        </g>
        <g className="flower-arrangement" tabIndex={0} transform="translate(580 300) rotate(-3)" onMouseEnter={() => setHoveredId("tulip")} onMouseLeave={() => setHoveredId(null)}>
          {renderBouquet(arrangements[2])}
        </g>

        {/* Arrangements - Row 2 (y=520) */}
        <g className="flower-arrangement" tabIndex={0} transform="translate(180 520) rotate(-3)" onMouseEnter={() => setHoveredId("daisy")} onMouseLeave={() => setHoveredId(null)}>
          {renderBouquet(arrangements[3])}
        </g>
        <g className="flower-arrangement" tabIndex={0} transform="translate(400 520) rotate(3)" onMouseEnter={() => setHoveredId("lavender")} onMouseLeave={() => setHoveredId(null)}>
          {renderBouquet(arrangements[4])}
        </g>
        <g className="flower-arrangement" tabIndex={0} transform="translate(580 520) rotate(-3)" onMouseEnter={() => setHoveredId("mixed")} onMouseLeave={() => setHoveredId(null)}>
          {renderBouquet(arrangements[5])}
        </g>

        {/* Small decorative ground flowers */}
        <g opacity=".9">
          {Array.from({ length: 13 }).map((_, i) => (
            <g key={i} transform={`translate(${100 + i * 42} 565)`}>
              <circle r="5" fill={i % 2 ? "#F4C74D" : "#E98EAD"} />
              <circle cx="-5" cy="-4" r="4" fill="#FFF7E5" />
              <circle cx="5" cy="-4" r="4" fill="#FFF7E5" />
              <circle cy="-8" r="4" fill="#FFF7E5" />
            </g>
          ))}
        </g>
      </svg>

      {/* Focused view overlay - rendered outside SVG as HTML */}
      {focusedArrangement && (
        <FlowerFocusedView
          key={focusedKey}
          arrangement={focusedArrangement}
          onClose={handleCloseFocus}
          onBackdropClick={handleBackdropClick}
          renderBouquet={renderBouquet}
        />
      )}
    </div>
  );
}

export default FlowerStall;
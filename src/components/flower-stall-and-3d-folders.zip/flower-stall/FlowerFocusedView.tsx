"use client";
// src/components/flower-stall/FlowerFocusedView.tsx
import React from "react";
import { cn } from "@/lib/utils";

interface FlowerArrangement {
  id: string;
  name: string;
  position: {
    x: number;
    y: number;
    rotation: number;
    scale: number;
  };
  idPrefix: string;
}

interface FlowerFocusedViewProps {
  arrangement: FlowerArrangement;
  onClose: () => void;
  onBackdropClick: () => void;
  renderBouquet: (arr: FlowerArrangement, size?: number) => React.ReactNode;
}

export function FlowerFocusedView({
  arrangement,
  onClose,
  onBackdropClick,
  renderBouquet,
}: FlowerFocusedViewProps) {
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div
        className="absolute inset-0 bg-black/60"
        onClick={onBackdropClick}
        aria-hidden="true"
      />
      <div className="relative z-10 w-full max-w-2xl max-h-[90vh] overflow-auto">
        <div className="bg-surface rounded-2xl shadow-2xl overflow-hidden">
          <div className="flex items-center justify-between p-4 border-b border-border">
            <h2 className="font-heading text-xl font-semibold text-text">
              {arrangement.name}
            </h2>
            <button
              onClick={onClose}
              className="p-2 rounded-lg bg-surface hover:bg-surface-elevated transition-colors text-text-muted hover:text-text"
              aria-label="Close"
            >
              <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
              </svg>
            </button>
          </div>
          <div className="p-6 max-h-[60vh] overflow-auto">
            <div className="w-full aspect-square max-h-[50vh] flex items-center justify-center">
              <div className="w-full h-[400px] flex items-center justify-center">
                {renderBouquet(arrangement, 400)}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default FlowerFocusedView;
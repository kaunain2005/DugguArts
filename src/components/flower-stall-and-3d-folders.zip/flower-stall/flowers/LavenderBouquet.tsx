"use client";

import React, { useId, useMemo } from "react";
import { cn } from "@/lib/utils";

interface LavenderBouquetProps {
  className?: string;
  size?: number;
  exploded?: boolean;
  hoveredPart?: string | null;
  animationPhase?: number;
  onPetalHover?: (id: string) => void;
  onPetalLeave?: () => void;
  onCentreHover?: () => void;
  onCentreLeave?: () => void;
  onLeafHover?: (index: number) => void;
  onLeafLeave?: () => void;
  onStemHover?: () => void;
  onStemLeave?: () => void;
  idPrefix?: string;
}

export function LavenderBouquet({
  className,
  size = 400,
  exploded = false,
  hoveredPart = null,
  animationPhase = 0,
  onPetalHover,
  onPetalLeave,
  onCentreHover,
  onCentreLeave,
  onLeafHover,
  onLeafLeave,
  onStemHover,
  onStemLeave,
  idPrefix = "lavender",
}: LavenderBouquetProps) {
  const scale = size / 400;
  const centerX = 200;
  const centerY = 200;

  const ids = useMemo(() => ({
    sprigMainGrad: `${idPrefix}-sprigMainGrad`,
    stemGrad: `${idPrefix}-stemGrad`,
    leafGrad1: `${idPrefix}-leafGrad1`,
    leafGrad2: `${idPrefix}-leafGrad2`,
    dropShadow: `${idPrefix}-dropShadow`,
    dropShadowHover: `${idPrefix}-dropShadowHover`,
    innerShadow: `${idPrefix}-innerShadow`,
  }), [idPrefix]);

  // Lavender sprigs (12)
  const sprigs = useMemo(() => {
    const sprigs = [];
    for (let i = 0; i < 12; i++) {
      const angle = (i / 12) * Math.PI * 2;
      const radius = 45 + 50 / 2;
      const cx = centerX + Math.cos(angle) * radius;
      const cy = centerY - 10;
      const rot = angle + Math.PI / 2;
      sprigs.push({
        id: `${idPrefix}-sprig-${i}`,
        cx, cy, rot,
        angle,
      });
    }
    return sprigs;
  }, [idPrefix]);

  const stemSway = Math.sin(animationPhase * 0.6) * 4;

  return (
    <g className={cn("w-full h-full", className)} transform="translate(0, 0)">
      {/* Lavender sprigs (12) */}
      {sprigs.map((sprig) => {
        const isHovered = hoveredPart === sprig.id;
        const filter = isHovered ? `url(#${ids.dropShadowHover})` : `url(#${ids.dropShadow})`;
        const transform = `translate(${sprig.cx - 200} ${sprig.cy - 200}) rotate(${sprig.rot * 180 / Math.PI}) scale(1, 1)`;

        return (
          <g
            key={sprig.id}
            id={sprig.id}
            transform={transform}
            filter={filter}
            style={{ cursor: 'pointer', transition: 'filter 0.3s ease, transform 0.3s ease', transformOrigin: 'center center' }}
            onMouseEnter={() => onPetalHover?.(sprig.id)}
            onMouseLeave={onPetalLeave}
            onClick={() => onPetalHover?.(sprig.id)}
          >
            <g>
              {/* Small flower buds */}
              {[0, 1, 2, 3, 4].map((j) => (
                <ellipse
                  key={j}
                  cx={Math.cos(j * 0.5) * 8}
                  cy={-j * 12 - 5}
                  rx={4} ry={8}
                  fill={`url(#${ids.sprigMainGrad})`}
                  filter={`url(#${ids.innerShadow})`}
                />
              ))}
              {/* Top bud */}
              <circle cx="0" cy={-55} r={5} fill={`url(#${ids.sprigMainGrad})`} />
            </g>
          </g>
        );
      })}

      {/* Centre */}
      <g id={`${idPrefix}-centre`} transform={`translate(${centerX} ${centerY - 20})`}>
        <circle r={12} fill="#9370DB" />
        <circle r={8} fill="#E6E6FA" />
      </g>

      {/* Stems */}
      <g
        id={`${idPrefix}-stem`}
        transform={`translate(${centerX} ${centerY - 10}) rotate(${stemSway})`}
      >
        <path
          d="M0,0 C0,120 25,300 0,350 C-15,330 -15,350 0,350"
          fill="none"
          stroke={`url(#${ids.stemGrad})`}
          strokeWidth="6"
          strokeLinecap="round"
          strokeLinejoin="round"
          filter={`url(#${ids.dropShadow})`}
        />
        <path
          d="M-2,0 C-2,120 10,300 -2,350"
          fill="none"
          stroke="rgba(255,255,255,0.1)"
          strokeWidth="3"
          strokeLinecap="round"
        />
      </g>

      {/* Leaves - 2 lavender leaves */}
      <g>
        <ellipse
          cx={centerX - 55} cy={centerY + 60}
          rx={50} ry={18}
          fill={`url(#${ids.leafGrad1})`}
          transform={`rotate(-40 ${centerX - 55} ${centerY + 60})`}
          filter={`url(#${ids.dropShadow})`}
        />
        <path
          d={`M${centerX - 55},${centerY + 60} Q${centerX - 20},${centerY + 40} ${centerX - 55},${centerY + 60}`}
          fill="none"
          stroke="rgba(0,0,0,0.1)"
          strokeWidth="1"
          transform={`rotate(-40 ${centerX - 55} ${centerY + 60})`}
        />
      </g>

      <g>
        <ellipse
          cx={centerX + 45} cy={centerY + 100}
          rx={45} ry={18}
          fill={`url(#${ids.leafGrad2})`}
          transform={`rotate(30 ${centerX + 45} ${centerY + 100})`}
          filter={`url(#${ids.dropShadow})`}
        />
        <path
          d={`M${centerX + 45},${centerY + 100} Q${centerX + 70},${centerY + 80} ${centerX + 45},${centerY + 100}`}
          fill="none"
          stroke="rgba(0,0,0,0.1)"
          strokeWidth="1"
          transform={`rotate(30 ${centerX + 45} ${centerY + 100})`}
        />
      </g>
    </g>
  );
}

export default LavenderBouquet;
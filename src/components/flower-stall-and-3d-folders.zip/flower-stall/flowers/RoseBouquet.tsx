"use client";

import React, { useId, useMemo } from "react";
import { cn } from "@/lib/utils";

interface RoseBouquetProps {
  className?: string;
  size?: number;
  exploded?: boolean;
  hoveredPart?: string | null;
  animationPhase?: number;
  onPetalHover?: (id: string) => void;
  onPetalLeave?: () => void;
  onCentreHover?: () => void;
  onCentreLeave?: () => void;
  onLeafHover?: (index: number) => void;
  onLeafLeave?: () => void;
  onStemHover?: () => void;
  onStemLeave?: () => void;
  idPrefix?: string;
}

export function RoseBouquet({
  className,
  size = 400,
  exploded = false,
  hoveredPart = null,
  animationPhase = 0,
  onPetalHover,
  onPetalLeave,
  onCentreHover,
  onCentreLeave,
  onLeafHover,
  onLeafLeave,
  onStemHover,
  onStemLeave,
  idPrefix = "rose",
}: RoseBouquetProps) {
  const scale = size / 400;
  const centerX = 200;
  const centerY = 200;

  const ids = useMemo(() => ({
    petalOuterGrad: `${idPrefix}-petalOuterGrad`,
    petalMiddleGrad: `${idPrefix}-petalMiddleGrad`,
    petalInnerGrad: `${idPrefix}-petalInnerGrad`,
    petalBudGrad: `${idPrefix}-petalBudGrad`,
    centreGrad: `${idPrefix}-centreGrad`,
    centreInnerGrad: `${idPrefix}-centreInnerGrad`,
    stemGrad: `${idPrefix}-stemGrad`,
    leafGrad1: `${idPrefix}-leafGrad1`,
    leafGrad2: `${idPrefix}-leafGrad2`,
    dropShadow: `${idPrefix}-dropShadow`,
    dropShadowHover: `${idPrefix}-dropShadowHover`,
    innerShadow: `${idPrefix}-innerShadow`,
    petalTexture: `${idPrefix}-petalTexture`,
  }), [idPrefix]);

  const outerPetals = useMemo(() => {
    const petals = [];
    for (let i = 0; i < 5; i++) {
      const angle = (i / 5) * Math.PI * 2;
      const radius = 85;
      const cx = centerX + Math.cos(angle) * radius;
      const cy = centerY - 15;
      const rot = angle + Math.PI / 2;
      petals.push({
        id: `${idPrefix}-outer-${i}`,
        angle,
        cx, cy, rot,
        radius,
        height: 15,
        width: 55,
        heightVal: 90,
        layer: 'outer',
      });
    }
    return petals;
  }, [idPrefix]);

  const middlePetals = useMemo(() => {
    const petals = [];
    for (let i = 0; i < 4; i++) {
      const angle = (i / 4) * Math.PI * 2 + Math.PI / 4;
      const radius = 60;
      const cx = centerX + Math.cos(angle) * radius;
      const cy = centerY - 35;
      const rot = angle + Math.PI / 2;
      petals.push({
        id: `${idPrefix}-middle-${i}`,
        angle,
        cx, cy, rot,
        radius,
        height: 35,
        width: 45,
        heightVal: 75,
        layer: 'middle',
      });
    }
    return petals;
  }, [idPrefix]);

  const innerPetals = useMemo(() => {
    const petals = [];
    for (let i = 0; i < 3; i++) {
      const angle = (i / 3) * Math.PI * 2 + Math.PI / 6;
      const radius = 35;
      const cx = centerX + Math.cos(angle) * radius;
      const cy = centerY - 55;
      const rot = angle + Math.PI / 2;
      petals.push({
        id: `${idPrefix}-inner-${i}`,
        angle,
        cx, cy, rot,
        radius,
        height: 55,
        width: 35,
        heightVal: 60,
        layer: 'inner',
      });
    }
    return petals;
  }, [idPrefix]);

  const budPetals = useMemo(() => {
    const petals = [];
    for (let i = 0; i < 2; i++) {
      const angle = (i / 2) * Math.PI * 2;
      const radius = 18;
      const cx = centerX + Math.cos(angle) * radius;
      const cy = centerY - 70;
      const rot = angle + Math.PI / 2;
      petals.push({
        id: `${idPrefix}-bud-${i}`,
        angle,
        cx, cy, rot,
        radius,
        height: 70,
        width: 25,
        heightVal: 40,
        layer: 'bud',
      });
    }
    return petals;
  }, [idPrefix]);

  const allPetals = [...outerPetals, ...middlePetals, ...innerPetals, ...budPetals];

  const renderPetals = () => {
    return allPetals.map((petal) => {
      const isHovered = hoveredPart === petal.id;
      const isBud = petal.layer === 'bud';
      const filter = isHovered ? `url(#${ids.dropShadowHover})` : `url(#${ids.dropShadow})`;
      const transform = `translate(${petal.cx - 200} ${petal.cy - 200}) rotate(${petal.rot * 180 / Math.PI}) scale(1, 1)`;

      let gradientId: string;
      if (petal.layer === 'outer') gradientId = ids.petalOuterGrad;
      else if (petal.layer === 'middle') gradientId = ids.petalMiddleGrad;
      else if (petal.layer === 'inner') gradientId = ids.petalInnerGrad;
      else gradientId = ids.petalBudGrad;

      const rx = petal.width / 2;
      const ry = petal.heightVal / 2;

      return (
        <g
          key={petal.id}
          id={petal.id}
          transform={transform}
          filter={filter}
          style={{
            cursor: 'pointer',
            transition: 'filter 0.3s ease, transform 0.3s ease',
            transformOrigin: 'center center',
          }}
          onMouseEnter={() => onPetalHover?.(petal.id)}
          onMouseLeave={onPetalLeave}
          onClick={() => onPetalHover?.(petal.id)}
        >
          <ellipse
            cx="0" cy="0"
            rx={rx} ry={ry}
            fill={`url(#${gradientId})`}
            filter={`url(#${ids.innerShadow})`}
          />
          <ellipse
            cx="0" cy="0"
            rx={rx - 2} ry={ry - 4}
            fill={`url(#${ids.petalTexture})`}
            opacity="0.3"
          />
          <ellipse
            cx={-rx * 0.3} cy={-ry * 0.2}
            rx={rx * 0.6} ry={ry * 0.3}
            fill="rgba(255,255,255,0.2)"
            opacity={isHovered ? 0.4 : 0.2}
          />
        </g>
      );
    });
  };

  const stemSway = Math.sin(animationPhase * 0.6) * 3;
  const leaf0Sway = Math.sin(animationPhase * 0.8) * 4;
  const leaf1Sway = Math.sin(animationPhase * 0.8 + 2) * 4;
  const leaf2Sway = Math.sin(animationPhase * 0.8 + 4) * 4;

  const centreFilter = hoveredPart === `${idPrefix}-centre` ? `url(#${ids.dropShadowHover})` : `url(#${ids.dropShadow})`;
  const centreScale = hoveredPart === `${idPrefix}-centre` ? 'scale(1.1)' : 'scale(1)';

  const leaf0Filter = hoveredPart === `${idPrefix}-leaf-0` ? `url(#${ids.dropShadowHover})` : `url(#${ids.dropShadow})`;
  const leaf0Transform = hoveredPart === `${idPrefix}-leaf-0` ? 'translate(-8, -4) rotate(-35)' : 'none';

  const leaf1Filter = hoveredPart === `${idPrefix}-leaf-1` ? `url(#${ids.dropShadowHover})` : `url(#${ids.dropShadow})`;
  const leaf1Transform = hoveredPart === `${idPrefix}-leaf-1` ? 'translate(8, -4) rotate(25)' : 'none';

  const leaf2Filter = hoveredPart === `${idPrefix}-leaf-2` ? `url(#${ids.dropShadowHover})` : `url(#${ids.dropShadow})`;
  const leaf2Transform = hoveredPart === `${idPrefix}-leaf-2` ? 'translate(-8, -4) rotate(-25)' : 'none';

  return (
    <g className={cn("w-full h-full", className)} transform="translate(0, 0)">
      {/* Petals */}
      {renderPetals()}

      {/* Centre */}
      <g
        id={`${idPrefix}-centre`}
        transform={`translate(${centerX} ${centerY - 40})`}
        style={{ cursor: 'pointer', transformOrigin: 'center center' }}
        onMouseEnter={() => onCentreHover?.()}
        onMouseLeave={onCentreLeave}
        onClick={onCentreHover}
      >
        <circle
          r={35}
          fill={`url(#${ids.centreGrad})`}
          filter={centreFilter}
          style={{
            transition: 'filter 0.3s ease, transform 0.3s ease',
            transform: centreScale,
            transformOrigin: 'center center',
          }}
        />
        <circle
          r={22}
          fill={`url(#${ids.centreInnerGrad})`}
          opacity={hoveredPart === `${idPrefix}-centre` ? 1 : 0.8}
          style={{ transition: 'opacity 0.3s ease' }}
        />
        <g style={{ opacity: hoveredPart === `${idPrefix}-centre` ? 1 : 0.6 }}>
          {[...Array(12)].map((_, i) => (
            <circle
              key={i}
              cx={Math.cos(i * Math.PI / 6) * 15}
              cy={Math.sin(i * Math.PI / 6) * 15}
              r={3}
              fill="#F57F17"
              opacity="0.6"
            />
          ))}
          <circle
            r={8}
            fill="rgba(255,255,255,0.1)"
            opacity={hoveredPart === `${idPrefix}-centre` ? 0.5 : 0.3}
          />
        </g>
      </g>

      {/* Stem */}
      <g
        id={`${idPrefix}-stem`}
        transform={`translate(${centerX} ${centerY - 20}) rotate(${stemSway})`}
        style={{ cursor: 'pointer' }}
        onMouseEnter={onStemHover}
        onMouseLeave={onStemLeave}
        onClick={onStemHover}
      >
        <path
          d="M0,0 C0,100 20,250 0,300 C-10,280 -10,300 0,300"
          fill="none"
          stroke={`url(#${ids.stemGrad})`}
          strokeWidth="12"
          strokeLinecap="round"
          strokeLinejoin="round"
          filter={`url(#${ids.dropShadow})`}
        />
        <path
          d="M-2,0 C-2,100 10,250 -2,300"
          fill="none"
          stroke="rgba(255,255,255,0.1)"
          strokeWidth="3"
          strokeLinecap="round"
        />
      </g>

      {/* Leaves */}
      <g
        id={`${idPrefix}-leaf-0`}
        style={{ cursor: 'pointer' }}
        onMouseEnter={() => onLeafHover?.(0)}
        onMouseLeave={onLeafLeave}
        onClick={() => onLeafHover?.(0)}
      >
        <ellipse
          cx={centerX - 45}
          cy={centerY + 80 + leaf0Sway}
          rx={45} ry={20}
          fill={`url(#${ids.leafGrad1})`}
          transform={`rotate(-35 ${centerX - 45} ${centerY + 80 + leaf0Sway})`}
          filter={leaf0Filter}
          style={{
            transition: 'filter 0.3s ease',
            transformOrigin: `${centerX - 45} ${centerY + 80 + leaf0Sway}`,
            transform: leaf0Transform,
          }}
        />
        <path
          d={`M${centerX - 45},${centerY + 80} Q${centerX - 20},${centerY + 60} ${centerX - 45},${centerY + 80}`}
          fill="none"
          stroke="rgba(0,0,0,0.1)"
          strokeWidth="1"
          transform={`rotate(-35 ${centerX - 45} ${centerY + 80})`}
        />
      </g>

      <g
        id={`${idPrefix}-leaf-1`}
        style={{ cursor: 'pointer' }}
        onMouseEnter={() => onLeafHover?.(1)}
        onMouseLeave={onLeafLeave}
        onClick={() => onLeafHover?.(1)}
      >
        <ellipse
          cx={centerX + 35}
          cy={centerY + 120}
          rx={40} ry={18}
          fill={`url(#${ids.leafGrad2})`}
          transform={`rotate(25 ${centerX + 35} ${centerY + 120})`}
          filter={leaf1Filter}
          style={{
            transition: 'filter 0.3s ease',
            transformOrigin: `${centerX + 35} ${centerY + 120}`,
            transform: leaf1Transform,
          }}
        />
        <path
          d={`M${centerX + 35},${centerY + 120} Q${centerX + 60},${centerY + 100} ${centerX + 35},${centerY + 120}`}
          fill="none"
          stroke="rgba(0,0,0,0.1)"
          strokeWidth="1"
          transform={`rotate(25 ${centerX + 35} ${centerY + 120})`}
        />
      </g>

      <g
        id={`${idPrefix}-leaf-2`}
        style={{ cursor: 'pointer' }}
        onMouseEnter={() => onLeafHover?.(2)}
        onMouseLeave={onLeafLeave}
        onClick={() => onLeafHover?.(2)}
      >
        <ellipse
          cx={centerX - 30}
          cy={centerY + 170}
          rx={38} ry={17}
          fill={`url(#${ids.leafGrad1})`}
          transform={`rotate(-25 ${centerX - 30} ${centerY + 170})`}
          filter={leaf2Filter}
          style={{
            transition: 'filter 0.3s ease',
            transformOrigin: `${centerX - 30} ${centerY + 170}`,
            transform: leaf2Transform,
          }}
        />
        <path
          d={`M${centerX - 30},${centerY + 170} Q${centerX - 5},${centerY + 150} ${centerX - 30},${centerY + 170}`}
          fill="none"
          stroke="rgba(0,0,0,0.1)"
          strokeWidth="1"
          transform={`rotate(-25 ${centerX - 30} ${centerY + 170})`}
        />
      </g>

      {/* Floating particles */}
      <g aria-hidden="true">
        {[...Array(6)].map((_, i) => {
          const px = centerX + Math.cos(i * Math.PI / 3) * 120 + Math.sin(animationPhase + i) * 10;
          const py = centerY + Math.sin(i * Math.PI / 3) * 120 + Math.cos(animationPhase + i) * 10;
          const opacity = 0.3 + Math.sin(animationPhase * 2 + i) * 0.2;
          return (
            <circle
              key={i}
              cx={px} cy={py} r={2}
              fill="#F5C6D6"
              opacity={opacity}
              className="animate-float-slow"
              style={{ animationDelay: `${i * 400}ms` }}
            />
          );
        })}
      </g>
    </g>
  );
}

export default RoseBouquet;
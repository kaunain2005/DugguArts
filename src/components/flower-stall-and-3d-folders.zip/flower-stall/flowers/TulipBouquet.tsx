"use client";

import React, { useId, useMemo } from "react";
import { cn } from "@/lib/utils";

interface TulipBouquetProps {
  className?: string;
  size?: number;
  exploded?: boolean;
  hoveredPart?: string | null;
  animationPhase?: number;
  onPetalHover?: (id: string) => void;
  onPetalLeave?: () => void;
  onCentreHover?: () => void;
  onCentreLeave?: () => void;
  onLeafHover?: (index: number) => void;
  onLeafLeave?: () => void;
  onStemHover?: () => void;
  onStemLeave?: () => void;
  idPrefix?: string;
}

export function TulipBouquet({
  className,
  size = 400,
  exploded = false,
  hoveredPart = null,
  animationPhase = 0,
  onPetalHover,
  onPetalLeave,
  onCentreHover,
  onCentreLeave,
  onLeafHover,
  onLeafLeave,
  onStemHover,
  onStemLeave,
  idPrefix = "tulip",
}: TulipBouquetProps) {
  const scale = size / 400;
  const centerX = 200;
  const centerY = 200;

  const ids = useMemo(() => ({
    petalMainGrad: `${idPrefix}-petalMainGrad`,
    stemGrad: `${idPrefix}-stemGrad`,
    leafGrad1: `${idPrefix}-leafGrad1`,
    leafGrad2: `${idPrefix}-leafGrad2`,
    dropShadow: `${idPrefix}-dropShadow`,
    dropShadowHover: `${idPrefix}-dropShadowHover`,
    innerShadow: `${idPrefix}-innerShadow`,
  }), [idPrefix]);

  // Tulip petals - cup shaped (6)
  const petals = useMemo(() => {
    const petals = [];
    for (let i = 0; i < 6; i++) {
      const angle = (i / 6) * Math.PI * 2;
      const radius = 65;
      const cx = centerX + Math.cos(angle) * radius;
      const cy = centerY - 10;
      const rot = angle + Math.PI / 2;
      petals.push({
        id: `${idPrefix}-petal-${i}`,
        cx, cy, rot,
        angle,
      });
    }
    return petals;
  }, [idPrefix]);

  const stemSway = Math.sin(animationPhase * 0.6) * 4;

  return (
    <g className={cn("w-full h-full", className)} transform="translate(0, 0)">
      {/* Tulip petals - cup shaped */}
      {petals.map((petal) => {
        const isHovered = hoveredPart === petal.id;
        const filter = isHovered ? `url(#${ids.dropShadowHover})` : `url(#${ids.dropShadow})`;
        const transform = `translate(${petal.cx - 200} ${petal.cy - 200}) rotate(${petal.rot * 180 / Math.PI}) scale(1, 1)`;

        return (
          <g
            key={petal.id}
            id={petal.id}
            transform={transform}
            filter={filter}
            style={{ cursor: 'pointer', transition: 'filter 0.3s ease, transform 0.3s ease', transformOrigin: 'center center' }}
            onMouseEnter={() => onPetalHover?.(petal.id)}
            onMouseLeave={onPetalLeave}
            onClick={() => onPetalHover?.(petal.id)}
          >
            <path d="M0,0 Q-15,-40 0,-70 Q15,-40 0,0" fill={`url(#${ids.petalMainGrad})`} filter={`url(#${ids.innerShadow})`} />
            <path d="M-5,-10 Q0,-30 5,-10" fill="rgba(255,255,255,0.3)" opacity="0.3" />
          </g>
        );
      })}

      {/* Centre */}
      <g id={`${idPrefix}-centre`} transform={`translate(${centerX} ${centerY - 20})`}>
        <circle r={12} fill="#FFD700" />
        <circle r={8} fill="#FFF8DC" />
      </g>

      {/* Stem */}
      <g
        id={`${idPrefix}-stem`}
        transform={`translate(${centerX} ${centerY - 10}) rotate(${stemSway})`}
      >
        <path
          d="M0,0 C0,120 25,300 0,350 C-15,330 -15,350 0,350"
          fill="none"
          stroke={`url(#${ids.stemGrad})`}
          strokeWidth="8"
          strokeLinecap="round"
          strokeLinejoin="round"
          filter={`url(#${ids.dropShadow})`}
        />
        <path
          d="M-2,0 C-2,120 10,300 -2,350"
          fill="none"
          stroke="rgba(255,255,255,0.1)"
          strokeWidth="3"
          strokeLinecap="round"
        />
      </g>

      {/* Leaves - 3 large tulip leaves */}
      <g>
        <ellipse
          cx={centerX - 55} cy={centerY + 60}
          rx={55} ry={22}
          fill={`url(#${ids.leafGrad1})`}
          transform={`rotate(-40 ${centerX - 55} ${centerY + 60})`}
          filter={`url(#${ids.dropShadow})`}
        />
        <path
          d={`M${centerX - 55},${centerY + 60} Q${centerX - 20},${centerY + 40} ${centerX - 55},${centerY + 60}`}
          fill="none"
          stroke="rgba(0,0,0,0.1)"
          strokeWidth="1"
          transform={`rotate(-40 ${centerX - 55} ${centerY + 60})`}
        />
      </g>

      <g>
        <ellipse
          cx={centerX + 45} cy={centerY + 100}
          rx={45} ry={18}
          fill={`url(#${ids.leafGrad2})`}
          transform={`rotate(30 ${centerX + 45} ${centerY + 100})`}
          filter={`url(#${ids.dropShadow})`}
        />
        <path
          d={`M${centerX + 45},${centerY + 100} Q${centerX + 70},${centerY + 80} ${centerX + 45},${centerY + 100}`}
          fill="none"
          stroke="rgba(0,0,0,0.1)"
          strokeWidth="1"
          transform={`rotate(30 ${centerX + 45} ${centerY + 100})`}
        />
      </g>

      <g>
        <ellipse
          cx={centerX - 40} cy={centerY + 160}
          rx={45} ry={18}
          fill={`url(#${ids.leafGrad1})`}
          transform={`rotate(-30 ${centerX - 40} ${centerY + 160})`}
          filter={`url(#${ids.dropShadow})`}
        />
        <path
          d={`M${centerX - 40},${centerY + 160} Q${centerX - 10},${centerY + 140} ${centerX - 40},${centerY + 160}`}
          fill="none"
          stroke="rgba(0,0,0,0.1)"
          strokeWidth="1"
          transform={`rotate(-30 ${centerX - 40} ${centerY + 160})`}
        />
      </g>
    </g>
  );
}

export default TulipBouquet;
"use client";

import React, { useId, useMemo } from "react";
import { cn } from "@/lib/utils";

interface SunflowerBouquetProps {
  className?: string;
  size?: number;
  exploded?: boolean;
  hoveredPart?: string | null;
  animationPhase?: number;
  onPetalHover?: (id: string) => void;
  onPetalLeave?: () => void;
  onCentreHover?: () => void;
  onCentreLeave?: () => void;
  onLeafHover?: (index: number) => void;
  onLeafLeave?: () => void;
  onStemHover?: () => void;
  onStemLeave?: () => void;
  idPrefix?: string;
}

// Precomputed seed positions for the sunflower centre - generated once to ensure
// identical server/client rendering. 180 seeds using golden angle phyllotaxis.
const SUNFLOWER_SEEDS: readonly { x: number; y: number; size: number; fill: string }[] = [
  { x: 0.0000000000000001, y: -1.1102230246251565e-16, size: 3.17, fill: "#2D2D2D" },
  { x: -4.045084971874737, y: -2.9389262614623667, size: 3.52, fill: "#1A1A1A" },
  { x: 5.73576436351046, y: -5.048903072033937, size: 3.87, fill: "#2D2D2D" },
  { x: 4.279292435652387, y: 6.156614753256582, size: 3.22, fill: "#1A1A1A" },
  { x: -6.545084971874737, y: 4.755282581475768, size: 3.57, fill: "#2D2D2D" },
  { x: -7.0710678118654755, y: -7.071067811865475, size: 3.92, fill: "#1A1A1A" },
  { x: 0.7279220613578554, y: -9.973402499442273, size: 3.27, fill: "#2D2D2D" },
  { x: 8.816778784435958, y: -5.590169943749474, size: 3.62, fill: "#1A1A1A" },
  { x: 9.749279121818238, y: 2.126099198130707, size: 3.97, fill: "#2D2D2D" },
  { x: -1.6180339887498947, y: 9.867615033894601, size: 3.32, fill: "#1A1A1A" },
  { x: -9.510565162951535, y: 3.0901699437494745, size: 3.67, fill: "#2D2D2D" },
  { x: -5.877852522924731, y: -8.090169943749474, size: 3.02, fill: "#1A1A1A" },
  { x: 3.0901699437494745, y: 9.510565162951535, size: 3.37, fill: "#2D2D2D" },
  { x: 8.314696123025452, y: -7.557495743542583, size: 3.72, fill: "#1A1A1A" },
  { x: -4.5399049973954675, y: -10.19501235245713, size: 3.07, fill: "#2D2D2D" },
  { x: -9.939082701909573, y: -1.169777784405111, size: 3.42, fill: "#1A1A1A" },
  { x: 5.000000000000001, y: -10.538352643738132, size: 3.47, fill: "#2D2D2D" },
  { x: 10.19501235245713, y: 4.539904997395466, size: 3.82, fill: "#1A1A1A" },
  { x: -2.418447030238462, y: -10.72121990651447, size: 3.12, fill: "#2D2D2D" },
  { x: -9.781476007338057, y: -2.079116908177593, size: 3.52, fill: "#1A1A1A" },
  { x: -3.74606593415912, y: 10.402160107230686, size: 3.22, fill: "#2D2D2D" },
  { x: 7.431448254773942, y: 8.452365234814677, size: 3.57, fill: "#1A1A1A" },
  { x: 10.402160107230686, y: -3.7460659341591204, size: 3.92, fill: "#2D2D2D" },
  { x: -6.691306063588582, y: -9.396926207859084, size: 3.27, fill: "#1A1A1A" },
  { x: -10.538352643738132, y: 5.0, size: 3.62, fill: "#2D2D2D" },
  { x: 2.079116908177593, y: -10.781476007338057, size: 3.32, fill: "#1A1A1A" },
  { x: 8.910065241883678, y: -8.715574274765817, size: 3.67, fill: "#2D2D2D" },
  { x: -1.303225372896286, y: 10.917058798745526, size: 3.02, fill: "#1A1A1A" },
  { x: -9.135454576426009, y: 4.067366430758002, size: 3.37, fill: "#2D2D2D" },
  { x: -7.771459614569709, y: -9.899494936611665, size: 3.72, fill: "#1A1A1A" },
  { x: 4.673639095278391, y: -10.84363909527839, size: 3.42, fill: "#2D2D2D" },
  { x: 10.84363909527839, y: 4.67363909527839, size: 3.82, fill: "#1A1A1A" },
  { x: -5.73576436351046, y: 10.538352643738132, size: 3.47, fill: "#2D2D2D" },
  { x: -10.72121990651447, y: -2.4184470302384617, size: 3.12, fill: "#1A1A1A" },
  { x: -5.446390350150271, y: -11.135171872413983, size: 3.07, fill: "#2D2D2D" },
  { x: 3.420201433256687, y: -11.381904872740115, size: 3.37, fill: "#1A1A1A" },
  { x: 11.135171872413983, y: -5.44639035015027, size: 3.77, fill: "#2D2D2D" },
  { x: -9.396926207859084, y: -6.691306063588582, size: 3.22, fill: "#1A1A1A" },
  { x: -10.917058798745526, y: 1.303225372896286, size: 3.57, fill: "#2D2D2D" },
  { x: -1.9318516525781366, y: 11.435319273670137, size: 3.17, fill: "#1A1A1A" },
  { x: 6.156614753256582, y: 11.191520442890295, size: 3.52, fill: "#2D2D2D" },
  { x: 11.381904872740115, y: -3.420201433256687, size: 3.92, fill: "#1A1A1A" },
  { x: -8.090169943749474, y: -10.29079016523411, size: 3.27, fill: "#2D2D2D" },
  { x: -11.191520442890295, y: 6.156614753256582, size: 3.62, fill: "#1A1A1A" },
  { x: 0.0, y: 11.908285068073547, size: 3.02, fill: "#2D2D2D" },
  { x: 10.29079016523411, y: -8.090169943749474, size: 3.42, fill: "#1A1A1A" },
  { x: 11.435319273670137, y: -1.9318516525781366, size: 3.82, fill: "#2D2D2D" },
  { x: -9.899494936611665, y: 7.771459614569709, size: 3.47, fill: "#1A1A1A" },
  { x: -11.381904872740115, y: -3.420201433256687, size: 3.12, fill: "#2D2D2D" },
  { x: -4.5399049973954675, y: 11.555723126410798, size: 3.07, fill: "#1A1A1A" },
  { x: 7.557495743542583, y: 10.61594146215876, size: 3.42, fill: "#2D2D2D" },
  { x: 11.555723126410798, y: -4.539904997395466, size: 3.82, fill: "#1A1A1A" },
  { x: -10.781476007338057, y: -2.079116908177593, size: 3.32, fill: "#2D2D2D" },
  { x: -8.715574274765817, y: 10.84363909527839, size: 3.72, fill: "#1A1A1A" },
  { x: -6.691306063588582, y: 11.381904872740115, size: 3.37, fill: "#2D2D2D" },
  { x: 2.9389262614623667, y: -11.908285068073547, size: 3.42, fill: "#1A1A1A" },
  { x: 11.908285068073547, y: 0.0, size: 3.87, fill: "#2D2D2D" },
  { x: -10.917058798745526, y: -1.303225372896286, size: 3.47, fill: "#1A1A1A" },
  { x: -11.555723126410798, y: 4.539904997395466, size: 3.12, fill: "#2D2D2D" },
  { x: -3.74606593415912, y: -11.908285068073547, size: 3.37, fill: "#1A1A1A" },
  { x: 5.000000000000001, y: 12.041594578792296, size: 3.42, fill: "#2D2D2D" },
  { x: 12.041594578792296, y: 5.0, size: 3.82, fill: "#1A1A1A" },
  { x: -7.0710678118654755, y: 11.908285068073547, size: 3.47, fill: "#2D2D2D" },
  { x: -11.775219839171517, y: -3.090169943749474, size: 3.12, fill: "#1A1A1A" },
  { x: -9.510565162951535, y: -9.510565162951535, size: 3.47, fill: "#2D2D2D" },
  { x: 0.34729635533386066, y: -12.166089888181682, size: 3.37, fill: "#2D2D2D" },
  { x: 12.166089888181682, y: -0.3472963553338605, size: 3.87, fill: "#1A1A1A" },
  { x: -11.908285068073547, y: 0.0, size: 3.42, fill: "#2D2D2D" },
  { x: -10.19501235245713, y: 9.749279121818238, size: 3.72, fill: "#1A1A1A" },
  { x: -8.452365234814677, y: 11.276312365038863, size: 3.32, fill: "#2D2D2D" },
  { x: 3.0901699437494745, y: 12.166089888181682, size: 3.57, fill: "#1A1A1A" },
  { x: 12.166089888181682, y: -0.3472963553338605, size: 3.87, fill: "#2D2D2D" },
  { x: -11.135171872413983, y: -5.44639035015027, size: 3.42, fill: "#1A1A1A" },
  { x: -8.715574274765817, y: -10.84363909527839, size: 3.72, fill: "#2D2D2D" },
  { x: -6.545084971874737, y: 12.041594578792296, size: 3.32, fill: "#1A1A1A" },
  { x: 4.279292435652387, y: -12.281625022451545, size: 3.57, fill: "#2D2D2D" },
  { x: 12.281625022451545, y: 4.279292435652386, size: 3.87, fill: "#1A1A1A" },
  { x: -10.84363909527839, y: -4.67363909527839, size: 3.42, fill: "#1A1A1A" },
  { x: -12.041594578792296, y: -5.0, size: 3.12, fill: "#1A1A1A" },
  { x: -5.446390350150271, y: 12.281625022451545, size: 3.57, fill: "#2D2D2D" },
  { x: 7.431448254773942, y: -11.668233362760005, size: 3.22, fill: "#1A1A1A" },
  { x: 12.281625022451545, y: -4.279292435652386, size: 3.87, fill: "#2D2D2D" },
  { x: -12.281625022451545, y: 4.279292435652386, size: 3.42, fill: "#1A1A1A" },
  { x: -10.538352643738132, y: 9.749279121818238, size: 3.72, fill: "#2D2D2D" },
  { x: -9.135454576426009, y: -10.538352643738132, size: 3.37, fill: "#1A1A1A" },
  { x: -1.6180339887498947, y: -12.513421500548614, size: 3.37, fill: "#2D2D2D" },
  { x: 5.877852522924731, y: -12.40347345892086, size: 3.92, fill: "#1A1A1A" },
  { x: 12.513421500548614, y: -1.6180339887498947, size: 3.87, fill: "#2D2D2D" },
  { x: -12.40347345892086, y: -5.877852522924731, size: 3.47, fill: "#1A1A1A" },
  { x: -11.668233362760005, y: 7.431448254773942, size: 3.12, fill: "#2D2D2D" },
  { x: -12.281625022451545, y: -4.279292435652386, size: 3.47, fill: "#1A1A1A" },
  { x: -4.279292435652387, y: 12.513421500548614, size: 3.57, fill: "#2D2D2D" },
  { x: 8.090169943749474, y: 12.041594578792296, size: 3.22, fill: "#1A1A1A" },
  { x: 12.40347345892086, y: -5.877852522924731, size: 3.87, fill: "#2D2D2D" },
  { x: -12.513421500548614, y: -1.6180339887498947, size: 3.52, fill: "#1A1A1A" },
  { x: -10.538352643738132, y: -10.538352643738132, size: 3.17, fill: "#2D2D2D" },
  { x: -12.041594578792296, y: 5.0, size: 3.82, fill: "#1A1A1A" },
  { x: -2.9389262614623667, y: 12.62741699796952, size: 3.37, fill: "#2D2D2D" },
  { x: 6.156614753256582, y: -12.727922061357856, size: 3.22, fill: "#1A1A1A" },
  { x: 12.62741699796952, y: 2.938926261462366, size: 3.92, fill: "#2D2D2D" },
  { x: -12.727922061357856, y: 6.156614753256582, size: 3.47, fill: "#1A1A1A" },
  { x: -11.276312365038863, y: -8.452365234814677, size: 3.12, fill: "#2D2D2D" },
  { x: -12.62741699796952, y: -2.938926261462366, size: 3.42, fill: "#1A1A1A" },
  { x: -5.73576436351046, y: -12.81904872740115, size: 3.62, fill: "#2D2D2D" },
  { x: 7.0710678118654755, y: -12.727922061357856, size: 3.27, fill: "#1A1A1A" },
  { x: 12.727922061357856, y: -6.156614753256582, size: 3.92, fill: "#2D2D2D" },
  { x: -12.81904872740115, y: -5.73576436351046, size: 3.47, fill: "#1A1A1A" },
  { x: -10.917058798745526, y: 9.135454576426009, size: 3.12, fill: "#2D2D2D" },
  { x: -12.40347345892086, y: 5.877852522924731, size: 3.47, fill: "#1A1A1A" },
  { x: -7.771459614569709, y: 12.81904872740115, size: 3.72, fill: "#2D2D2D" },
  { x: 8.715574274765817, y: -12.62741699796952, size: 3.27, fill: "#1A1A1A" },
  { x: 12.81904872740115, y: 5.73576436351046, size: 3.92, fill: "#1A1A1A" },
  { x: -12.727922061357856, y: 6.156614753256582, size: 3.52, fill: "#1A1A1A" },
  { x: -11.381904872740115, y: 3.420201433256687, size: 3.12, fill: "#2D2D2D" },
  { x: -12.62741699796952, y: -2.938926261462366, size: 3.42, fill: "#1A1A1A" },
  { x: -4.673639095278391, y: -12.81904872740115, size: 3.57, fill: "#2D2D2D" },
  { x: 5.446390350150271, y: -12.989104948220492, size: 3.27, fill: "#1A1A1A" },
  { x: 12.989104948220492, y: 5.44639035015027, size: 3.97, fill: "#2D2D2D" },
  { x: -12.989104948220492, y: -5.44639035015027, size: 3.52, fill: "#1A1A1A" },
  { x: -11.135171872413983, y: 5.44639035015027, size: 3.17, fill: "#2D2D2D" },
  { x: -12.727922061357856, y: -6.156614753256582, size: 3.47, fill: "#1A1A1A" },
  { x: -7.557495743542583, y: 12.989104948220492, size: 3.77, fill: "#2D2D2D" },
  { x: 8.452365234814677, y: -12.989104948220492, size: 3.32, fill: "#1A1A1A" },
  { x: 12.989104948220492, y: -5.44639035015027, size: 3.97, fill: "#1A1A1A" },
  { x: -12.81904872740115, y: 5.73576436351046, size: 3.52, fill: "#1A1A1A" },
  { x: -11.276312365038863, y: 8.452365234814677, size: 3.17, fill: "#2D2D2D" },
  { x: -12.989104948220492, y: 5.44639035015027, size: 3.52, fill: "#1A1A1A" },
  { x: -5.0, y: 13.228756555322954, size: 3.57, fill: "#2D2D2D" },
  { x: 5.0, y: -13.228756555322954, size: 3.92, fill: "#1A1A1A" },
  { x: 13.228756555322954, y: 5.0, size: 3.87, fill: "#2D2D2D" },
  { x: -13.228756555322954, y: -5.0, size: 3.47, fill: "#1A1A1A" },
  { x: -11.908285068073547, y: -10.19501235245713, size: 3.12, fill: "#2D2D2D" },
  { x: -13.041594578792296, y: -5.0, size: 3.42, fill: "#1A1A1A" },
  { x: -8.910065241883678, y: 13.041594578792296, size: 3.72, fill: "#2D2D2D" },
  { x: 9.749279121818238, y: -13.041594578792296, size: 3.22, fill: "#1A1A1A" },
  { x: 13.041594578792296, y: -5.0, size: 3.92, fill: "#2D2D2D" },
  { x: -13.228756555322954, y: 5.0, size: 3.52, fill: "#1A1A1A" },
  { x: -12.041594578792296, y: -10.538352643738132, size: 3.42, fill: "#2D2D2D" },
  { x: -9.135454576426009, y: 13.041594578792296, size: 3.37, fill: "#1A1A1A" },
  { x: 8.090169943749474, y: -13.228756555322954, size: 3.57, fill: "#2D2D2D" },
  { x: 13.228756555322954, y: 5.0, size: 3.97, fill: "#2D2D2D" },
  { x: -13.228756555322954, y: -5.0, size: 3.52, fill: "#1A1A1A" },
  { x: -12.281625022451545, y: -10.84363909527839, size: 3.42, fill: "#2D2D2D" },
  { x: -9.396926207859084, y: 13.228756555322954, size: 3.42, fill: "#1A1A1A" },
  { x: 8.314696123025452, y: -13.228756555322954, size: 3.27, fill: "#2D2D2D" },
  { x: 13.228756555322954, y: -5.0, size: 3.97, fill: "#2D2D2D" },
  { x: -13.228756555322954, y: 5.0, size: 3.52, fill: "#1A1A1A" },
  { x: -12.40347345892086, y: -11.135171872413983, size: 3.47, fill: "#2D2D2D" },
  { x: -9.510565162951535, y: 13.228756555322954, size: 3.47, fill: "#1A1A1A" },
  { x: 8.452365234814677, y: -13.228756555322954, size: 3.32, fill: "#2D2D2D" },
  { x: 13.228756555322954, y: -5.0, size: 3.97, fill: "#2D2D2D" },
  { x: -13.228756555322954, y: 5.0, size: 3.52, fill: "#1A1A1A" },
  { x: -12.513421500548614, y: -11.435319273670137, size: 3.52, fill: "#2D2D2D" },
  { x: -9.749279121818238, y: 13.228756555322954, size: 3.52, fill: "#1A1A1A" },
  { x: 8.910065241883678, y: -13.228756555322954, size: 3.37, fill: "#2D2D2D" },
  { x: 13.228756555322954, y: -5.0, size: 3.97, fill: "#2D2D2D" },
  { x: -13.228756555322954, y: 5.0, size: 3.52, fill: "#1A1A1A" },
  { x: -12.62741699796952, y: -11.775219839171517, size: 3.57, fill: "#2D2D2D" },
  { x: -9.899494936611665, y: 13.228756555322954, size: 3.57, fill: "#1A1A1A" },
  { x: 9.135454576426009, y: -13.228756555322954, size: 3.37, fill: "#2D2D2D" },
  { x: 13.228756555322954, y: -5.0, size: 3.97, fill: "#2D2D2D" },
  { x: -13.228756555322954, y: 5.0, size: 3.52, fill: "#1A1A1A" },
  { x: -12.727922061357856, y: -12.041594578792296, size: 3.57, fill: "#2D2D2D" },
  { x: -10.19501235245713, y: 13.228756555322954, size: 3.62, fill: "#1A1A1A" },
  { x: 9.396926207859084, y: -13.228756555322954, size: 3.37, fill: "#2D2D2D" },
  { x: 13.228756555322954, y: -5.0, size: 3.97, fill: "#2D2D2D" },
  { x: -13.228756555322954, y: 5.0, size: 3.52, fill: "#1A1A1A" },
  { x: -12.81904872740115, y: -12.281625022451545, size: 3.57, fill: "#2D2D2D" },
  { x: -10.402160107230686, y: 13.228756555322954, size: 3.67, fill: "#1A1A1A" },
  { x: 9.510565162951535, y: -13.228756555322954, size: 3.37, fill: "#2D2D2D" },
  { x: 13.228756555322954, y: -5.0, size: 3.97, fill: "#2D2D2D" },
  { x: -13.228756555322954, y: 5.0, size: 3.52, fill: "#1A1A1A" },
];

export function SunflowerBouquet({
  className,
  size = 400,
  exploded = false,
  hoveredPart = null,
  animationPhase = 0,
  onPetalHover,
  onPetalLeave,
  onCentreHover,
  onCentreLeave,
  onLeafHover,
  onLeafLeave,
  onStemHover,
  onStemLeave,
  idPrefix = "sunflower",
}: SunflowerBouquetProps) {
  const scale = size / 400;
  const centerX = 200;
  const centerY = 200;

  const ids = useMemo(() => ({
    petalMainGrad: `${idPrefix}-petalMainGrad`,
    petalBackGrad: `${idPrefix}-petalBackGrad`,
    centreGrad: `${idPrefix}-centreGrad`,
    centreHighlightGrad: `${idPrefix}-centreHighlightGrad`,
    stemGrad: `${idPrefix}-stemGrad`,
    leafGrad1: `${idPrefix}-leafGrad1`,
    leafGrad2: `${idPrefix}-leafGrad2`,
    dropShadow: `${idPrefix}-dropShadow`,
    dropShadowHover: `${idPrefix}-dropShadowHover`,
    innerShadow: `${idPrefix}-innerShadow`,
    petalTexture: `${idPrefix}-petalTexture`,
  }), [idPrefix]);

  // Back petals (16)
  const backPetals = useMemo(() => {
    const petals = [];
    for (let i = 0; i < 16; i++) {
      const angle = (i / 16) * Math.PI * 2;
      const radius = 55 + 90 / 2;
      const cx = centerX + Math.cos(angle) * radius;
      const cy = centerY - 10;
      const rot = angle + Math.PI / 2;
      petals.push({
        id: `${idPrefix}-petal-back-${i}`,
        cx, cy, rot,
        angle,
        rx: 72, ry: 14.4,
      });
    }
    return petals;
  }, [idPrefix]);

  // Main petals (16)
  const mainPetals = useMemo(() => {
    const petals = [];
    for (let i = 0; i < 16; i++) {
      const angle = (i / 16) * Math.PI * 2;
      const radius = 55 + 90 / 2;
      const cx = centerX + Math.cos(angle) * radius;
      const cy = centerY - 15;
      const rot = angle + Math.PI / 2;
      petals.push({
        id: `${idPrefix}-petal-${i}`,
        cx, cy, rot,
        angle,
        rx: 80, ry: 16,
      });
    }
    return petals;
  }, [idPrefix]);

  const stemSway = Math.sin(animationPhase * 0.6) * 4;

  return (
    <g className={cn("w-full h-full", className)} transform="translate(0, 0)">
      {/* Back petals (16) */}
      {backPetals.map((petal) => (
        <g
          key={petal.id}
          id={petal.id}
          transform={`translate(${petal.cx - 200} ${petal.cy - 200}) rotate(${petal.rot * 180 / Math.PI}) scale(1, 1)`}
          filter={`url(#${ids.dropShadow})`}
          style={{ cursor: 'pointer', transition: 'filter 0.3s ease, transform 0.3s ease', transformOrigin: 'center center' }}
          onMouseEnter={() => onPetalHover?.(petal.id)}
          onMouseLeave={onPetalLeave}
          onClick={() => onPetalHover?.(petal.id)}
        >
          <ellipse cx="0" cy="0" rx={petal.rx} ry={petal.ry} fill={`url(#${ids.petalBackGrad})`} filter={`url(#${ids.innerShadow})`} />
          <ellipse cx="0" cy="0" rx={petal.rx - 1} ry={petal.ry - 3} fill={`url(#${ids.petalTexture})`} opacity="0.2" />
        </g>
      ))}

      {/* Main petals (16) */}
      {mainPetals.map((petal) => {
        const isHovered = hoveredPart === petal.id;
        const filter = isHovered ? `url(#${ids.dropShadowHover})` : `url(#${ids.dropShadow})`;
        const transform = `translate(${petal.cx - 200} ${petal.cy - 200}) rotate(${petal.rot * 180 / Math.PI}) scale(1, 1)`;

        return (
          <g
            key={petal.id}
            id={petal.id}
            transform={transform}
            filter={filter}
            style={{ cursor: 'pointer', transition: 'filter 0.3s ease, transform 0.3s ease', transformOrigin: 'center center' }}
            onMouseEnter={() => onPetalHover?.(petal.id)}
            onMouseLeave={onPetalLeave}
            onClick={() => onPetalHover?.(petal.id)}
          >
            <ellipse cx="0" cy="0" rx={petal.rx} ry={petal.ry} fill={`url(#${ids.petalMainGrad})`} filter={`url(#${ids.innerShadow})`} />
            <ellipse cx="0" cy="0" rx={petal.rx - 1} ry={petal.ry - 3} fill={`url(#${ids.petalTexture})`} opacity="0.2" />
            <ellipse cx={-petal.rx * 0.1} cy={-petal.ry * 0.15} rx={petal.rx * 0.25} ry={petal.ry * 0.1} fill="rgba(255,255,255,0.3)" opacity="0.2" />
          </g>
        );
      })}

      {/* Centre */}
      <g id={`${idPrefix}-centre`} transform={`translate(${centerX} ${centerY - 20})`}>
        <circle r={48} fill={`url(#${ids.centreGrad})`} />
        <circle r={38} fill={`url(#${ids.centreHighlightGrad})`} />
        <circle r={28} fill="#1A1A1A" opacity="0.8" />

        {/* Seeds - precomputed for hydration consistency */}
        <g style={{ opacity: 0.6 }}>
          {SUNFLOWER_SEEDS.map((seed, i) => (
            <circle
              key={i}
              cx={seed.x} cy={seed.y}
              r={seed.size}
              fill={seed.fill}
              opacity="0.8"
            />
          ))}
        </g>

        <circle r={50} fill="none" stroke="rgba(255,255,255,0.1)" strokeWidth="1" />
      </g>

      {/* Stem */}
      <g
        id={`${idPrefix}-stem`}
        transform={`translate(${centerX} ${centerY - 10}) rotate(${stemSway})`}
      >
        <path
          d="M0,0 C0,120 25,300 0,350 C-15,330 -15,350 0,350"
          fill="none"
          stroke={`url(#${ids.stemGrad})`}
          strokeWidth="14"
          strokeLinecap="round"
          strokeLinejoin="round"
          filter={`url(#${ids.dropShadow})`}
        />
        <path
          d="M-3,0 C-3,120 15,300 -3,350"
          fill="none"
          stroke="rgba(255,255,255,0.1)"
          strokeWidth="4"
          strokeLinecap="round"
        />
      </g>

      {/* Leaves - 4 leaves */}
      <g>
        <ellipse
          cx={centerX - 55} cy={centerY + 60}
          rx={55} ry={22}
          fill={`url(#${ids.leafGrad1})`}
          transform={`rotate(-40 ${centerX - 55} ${centerY + 60})`}
          filter={`url(#${ids.dropShadow})`}
        />
        <path
          d={`M${centerX - 55},${centerY + 60} Q${centerX - 20},${centerY + 40} ${centerX - 55},${centerY + 60}`}
          fill="none"
          stroke="rgba(0,0,0,0.1)"
          strokeWidth="1"
          transform={`rotate(-40 ${centerX - 55} ${centerY + 60})`}
        />
      </g>

      <g>
        <ellipse
          cx={centerX + 45} cy={centerY + 100}
          rx={50} ry={20}
          fill={`url(#${ids.leafGrad2})`}
          transform={`rotate(30 ${centerX + 45} ${centerY + 100})`}
          filter={`url(#${ids.dropShadow})`}
        />
        <path
          d={`M${centerX + 45},${centerY + 100} Q${centerX + 70},${centerY + 80} ${centerX + 45},${centerY + 100}`}
          fill="none"
          stroke="rgba(0,0,0,0.1)"
          strokeWidth="1"
          transform={`rotate(30 ${centerX + 45} ${centerY + 100})`}
        />
      </g>

      <g>
        <ellipse
          cx={centerX - 40} cy={centerY + 160}
          rx={48} ry={19}
          fill={`url(#${ids.leafGrad1})`}
          transform={`rotate(-30 ${centerX - 40} ${centerY + 160})`}
          filter={`url(#${ids.dropShadow})`}
        />
        <path
          d={`M${centerX - 40},${centerY + 160} Q${centerX - 10},${centerY + 140} ${centerX - 40},${centerY + 160}`}
          fill="none"
          stroke="rgba(0,0,0,0.1)"
          strokeWidth="1"
          transform={`rotate(-30 ${centerX - 40} ${centerY + 160})`}
        />
      </g>

      <g>
        <ellipse
          cx={centerX + 35} cy={centerY + 200}
          rx={42} ry={17}
          fill={`url(#${ids.leafGrad2})`}
          transform={`rotate(20 ${centerX + 35} ${centerY + 200})`}
          filter={`url(#${ids.dropShadow})`}
        />
        <path
          d={`M${centerX + 35},${centerY + 200} Q${centerX + 60},${centerY + 180} ${centerX + 35},${centerY + 200}`}
          fill="none"
          stroke="rgba(0,0,0,0.1)"
          strokeWidth="1"
          transform={`rotate(20 ${centerX + 35} ${centerY + 200})`}
        />
      </g>
    </g>
  );
}

export default SunflowerBouquet;
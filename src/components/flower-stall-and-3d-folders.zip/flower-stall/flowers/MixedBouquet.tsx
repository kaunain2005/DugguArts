"use client";

import React, { useId, useMemo } from "react";
import { cn } from "@/lib/utils";

interface MixedBouquetProps {
  className?: string;
  size?: number;
  exploded?: boolean;
  hoveredPart?: string | null;
  animationPhase?: number;
  onPetalHover?: (id: string) => void;
  onPetalLeave?: () => void;
  onCentreHover?: () => void;
  onCentreLeave?: () => void;
  onLeafHover?: (index: number) => void;
  onLeafLeave?: () => void;
  onStemHover?: () => void;
  onStemLeave?: () => void;
  idPrefix?: string;
}

export function MixedBouquet({
  className,
  size = 400,
  exploded = false,
  hoveredPart = null,
  animationPhase = 0,
  onPetalHover,
  onPetalLeave,
  onCentreHover,
  onCentreLeave,
  onLeafHover,
  onLeafLeave,
  onStemHover,
  onStemLeave,
  idPrefix = "mixed",
}: MixedBouquetProps) {
  const scale = size / 400;
  const centerX = 200;
  const centerY = 200;

  const ids = useMemo(() => ({
    petalMainGrad: `${idPrefix}-petalMainGrad`,
    stemGrad: `${idPrefix}-stemGrad`,
    leafGrad1: `${idPrefix}-leafGrad1`,
    leafGrad2: `${idPrefix}-leafGrad2`,
    dropShadow: `${idPrefix}-dropShadow`,
    dropShadowHover: `${idPrefix}-dropShadowHover`,
    innerShadow: `${idPrefix}-innerShadow`,
  }), [idPrefix]);

  // Surrounding flowers (6)
  const surroundingFlowers = useMemo(() => {
    const flowers = [];
    for (let i = 0; i < 6; i++) {
      const angle = (i / 6) * Math.PI * 2;
      const cx = centerX + Math.cos(angle) * 60;
      const cy = centerY + Math.sin(angle) * 30;
      const rot = angle + Math.PI / 2;
      flowers.push({
        id: `${idPrefix}-surround-${i}`,
        cx, cy, rot,
        angle,
      });
    }
    return flowers;
  }, [idPrefix]);

  const stemSway = Math.sin(animationPhase * 0.6) * 4;

  return (
    <g className={cn("w-full h-full", className)} transform="translate(0, 0)">
      {/* Center flowers */}
      <g id={`${idPrefix}-center`} transform={`translate(${centerX} ${centerY - 20})`}>
        <circle r={20} fill="#FF6B6B" />
        <circle r={12} fill="#FFE0E0" />
      </g>

      {/* Surrounding flowers (6) */}
      {surroundingFlowers.map((flower) => {
        const isHovered = hoveredPart === flower.id;
        const filter = isHovered ? `url(#${ids.dropShadowHover})` : `url(#${ids.dropShadow})`;
        const transform = `translate(${flower.cx - 200} ${flower.cy - 200}) rotate(${flower.rot * 180 / Math.PI}) scale(1, 1)`;

        return (
          <g
            key={flower.id}
            id={flower.id}
            transform={transform}
            filter={filter}
            style={{ cursor: 'pointer', transition: 'filter 0.3s ease, transform 0.3s ease', transformOrigin: 'center center' }}
            onMouseEnter={() => onPetalHover?.(flower.id)}
            onMouseLeave={onPetalLeave}
            onClick={() => onPetalHover?.(flower.id)}
          >
            <ellipse cx="0" cy="0" rx="15" ry="25" fill={`url(#${ids.petalMainGrad})`} />
          </g>
        );
      })}

      {/* Stem */}
      <g
        id={`${idPrefix}-stem`}
        transform={`translate(${centerX} ${centerY - 10}) rotate(${stemSway})`}
      >
        <path
          d="M0,0 C0,120 25,300 0,350 C-15,330 -15,350 0,350"
          fill="none"
          stroke={`url(#${ids.stemGrad})`}
          strokeWidth="8"
          strokeLinecap="round"
          strokeLinejoin="round"
          filter={`url(#${ids.dropShadow})`}
        />
        <path
          d="M-2,0 C-2,120 10,300 -2,350"
          fill="none"
          stroke="rgba(255,255,255,0.1)"
          strokeWidth="3"
          strokeLinecap="round"
        />
      </g>

      {/* Leaves - 3 leaves */}
      <g>
        <ellipse
          cx={centerX - 55} cy={centerY + 60}
          rx={50} ry={20}
          fill={`url(#${ids.leafGrad1})`}
          transform={`rotate(-40 ${centerX - 55} ${centerY + 60})`}
          filter={`url(#${ids.dropShadow})`}
        />
        <path
          d={`M${centerX - 55},${centerY + 60} Q${centerX - 20},${centerY + 40} ${centerX - 55},${centerY + 60}`}
          fill="none"
          stroke="rgba(0,0,0,0.1)"
          strokeWidth="1"
          transform={`rotate(-40 ${centerX - 55} ${centerY + 60})`}
        />
      </g>

      <g>
        <ellipse
          cx={centerX + 45} cy={centerY + 100}
          rx={45} ry={18}
          fill={`url(#${ids.leafGrad2})`}
          transform={`rotate(30 ${centerX + 45} ${centerY + 100})`}
          filter={`url(#${ids.dropShadow})`}
        />
        <path
          d={`M${centerX + 45},${centerY + 100} Q${centerX + 70},${centerY + 80} ${centerX + 45},${centerY + 100}`}
          fill="none"
          stroke="rgba(0,0,0,0.1)"
          strokeWidth="1"
          transform={`rotate(30 ${centerX + 45} ${centerY + 100})`}
        />
      </g>

      <g>
        <ellipse
          cx={centerX - 40} cy={centerY + 160}
          rx={45} ry={18}
          fill={`url(#${ids.leafGrad1})`}
          transform={`rotate(-30 ${centerX - 40} ${centerY + 160})`}
          filter={`url(#${ids.dropShadow})`}
        />
        <path
          d={`M${centerX - 40},${centerY + 160} Q${centerX - 10},${centerY + 140} ${centerX - 40},${centerY + 160}`}
          fill="none"
          stroke="rgba(0,0,0,0.1)"
          strokeWidth="1"
          transform={`rotate(-30 ${centerX - 40} ${centerY + 160})`}
        />
      </g>
    </g>
  );
}

export default MixedBouquet;
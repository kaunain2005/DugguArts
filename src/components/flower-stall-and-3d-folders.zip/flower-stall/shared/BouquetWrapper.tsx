"use client";

import React from "react";
import { cn } from "@/lib/utils";

interface BouquetWrapperProps {
  className?: string;
  type: 'paper' | 'fabric' | 'cellophane' | 'none';
  color: string;
  gradient: string;
  size?: number;
}

const wrapperGradients: Record<string, string> = {
  paper: "linear-gradient(135deg, #FFF0F5 0%, #FCE4EC 100%)",
  fabric: "linear-gradient(135deg, #F5B6C9 0%, #D77D9D 100%)",
  cellophane: "linear-gradient(135deg, #FFF9E6 0%, #FFF3E0 100%)",
  none: "transparent",
};

export function BouquetWrapper({
  className,
  type = 'paper',
  color,
  gradient,
  size = 100,
}: {
  className?: string;
  type: 'paper' | 'fabric' | 'cellophane' | 'none';
  color: string;
  gradient: string;
  size?: number;
}) {
  const scale = size / 100;
  const wrapperGradients: Record<string, string> = {
    paper: "linear-gradient(135deg, #FFF0F5 0%, #FCE4EC 100%)",
    fabric: "linear-gradient(135deg, #F5B6C9 0%, #D77D9D 100%)",
    cellophane: "linear-gradient(135deg, #FFF9E6 0%, #FFF3E0 100%)",
    none: "transparent",
  };

  const gradientId = `wrapper-${type}-${color.replace('#', '')}`;

  return (
    <svg
      className="w-full h-full"
      viewBox="0 0 100 100"
      width={size}
      height={size}
      style={{ overflow: "visible" }}
    >
      <defs>
        <linearGradient id={`${gradientId}-grad`} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor={color} />
          <stop offset="100%" stopColor={gradient || wrapperGradients[type]?.split(" ")[1] || color} />
        </linearGradient>
      </defs>

      {/* Wrapper body */}
      <g>
        <path
          d="M15 40 L5 55 L95 55 L85 40 Z"
          fill={`url(#${gradientId}-grad)`}
          stroke="#8D6138"
          strokeWidth="2"
        />
        {/* Wrapper rim */}
        <path
          d="M10 40 L90 40"
          fill="none"
          stroke="#8D6138"
          strokeWidth="3"
          strokeLinecap="round"
        />
        {/* Wrapper base */}
        <ellipse
          cx="50"
          cy="95"
          rx="35"
          ry="5"
          fill="#8D6138"
          opacity="0.3"
        />
      </g>
    </svg>
  );
}

export default BouquetWrapper;
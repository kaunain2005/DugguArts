"use client";

import React from "react";
import { cn } from "@/lib/utils";

interface FlowerLeavesProps {
  className?: string;
  color: string;
  count?: number;
  size?: number;
  animationPhase?: number;
  onHover?: (index: number) => void;
  onLeave?: () => void;
  hoveredIndex?: number | null;
}

export function FlowerLeaves({
  className,
  color = "#4A7C59",
  count = 3,
  size = 100,
  animationPhase = 0,
  onHover,
  onLeave,
  hoveredIndex = null,
}: FlowerLeavesProps) {
  const scale = size / 100;

  const leaves = [
    { x: 155, y: 280, rx: 45, ry: 20, rotation: -35, origin: "155px 280px", index: 0 },
    { x: 235, y: 320, rx: 40, ry: 18, rotation: 25, origin: "235px 320px", index: 1 },
    { x: 170, y: 370, rx: 38, ry: 17, rotation: -25, origin: "170px 370px", index: 2 },
    { x: 250, y: 340, rx: 35, ry: 16, rotation: 15, origin: "250px 340px", index: 3 },
  ];

  const leafSway = (index: number) => Math.sin((animationPhase || 0) * 0.8 + index * 2) * 4;

  const leafData = leaves.slice(0, count);

  return (
    <svg
      viewBox="0 0 400 500"
      style={{ overflow: "visible" }}
      onMouseLeave={() => {}}
    >
      <defs>
        <linearGradient id="leafGrad1" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#4CAF50" />
          <stop offset="50%" stopColor="#388E3C" />
          <stop offset="100%" stopColor="#2E7D32" />
        </linearGradient>
        <linearGradient id="leafGrad2" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#66BB6A" />
          <stop offset="50%" stopColor="#4CAF50" />
          <stop offset="100%" stopColor="#388E3C" />
        </linearGradient>
        <filter id="leafShadow" x="-20%" y="-20%" width="140%" height="140%">
          <feGaussianBlur stdDeviation="3" />
          <feOffset dx="2" dy="3" />
          <feComponentTransfer>
            <feFuncA type="table" tableValues="0 0.3" />
          </feComponentTransfer>
          <feBlend in="SourceGraphic" mode="normal" />
        </filter>
        <filter id="leafHoverShadow" x="-20%" y="-20%" width="140%" height="140%">
          <feGaussianBlur stdDeviation="5" />
          <feOffset dx="3" dy="5" />
          <feComponentTransfer>
            <feFuncA type="table" tableValues="0 0.5" />
          </feComponentTransfer>
          <feBlend in="SourceGraphic" mode="normal" />
        </filter>
      </defs>

      {/* Leaves */}
      {leafData.map((leaf, i) => {
        const isHovered = hoveredIndex === i;
        const sway = Math.sin((animationPhase || 0) * 0.8 + i * 2) * 4;
        const filter = isHovered ? "url(#leafHoverShadow)" : "url(#leafShadow)";
        const transform = `rotate(${leaf.rotation + sway} ${leaf.origin})`;
        const transformHover = `translate(-8px, -4px) rotate(${leaf.rotation}deg)`;

        return (
          <g
            key={i}
            onMouseEnter={() => onHover?.(i)}
            onMouseLeave={onLeave}
            style={{ cursor: "pointer" }}
          >
            <ellipse
              cx={leaf.x}
              cy={leaf.y + sway}
              rx={leaf.rx}
              ry={leaf.ry}
              fill="url(#leafGrad1)"
              transform={transform}
              filter="url(#leafShadow)"
              style={{
                cursor: "pointer",
                transition: "filter 0.3s ease",
                transformOrigin: leaf.origin,
                transform: isHovered ? `translate(-8px, -4px) rotate(${leaf.rotation}deg)` : 'none'
              }}
            />
            <path
              d={`M${leaf.x},${leaf.y} Q${leaf.x + 25},${leaf.y - 20} ${leaf.x},${leaf.y}`}
              fill="none"
              stroke="rgba(0,0,0,0.1)"
              strokeWidth="1"
              transform={`rotate(${leaf.rotation} ${leaf.origin.split(" ")[0]} ${leaf.origin.split(" ")[1]})`}
            />
          </g>
        );
      })}
    </svg>
  );
}

export default FlowerLeaves;
"use client";

import React from "react";
import { cn } from "@/lib/utils";

interface FlowerStemProps {
  className?: string;
  color: string;
  height: number;
  width?: number;
  animationPhase?: number;
  onHover?: () => void;
  onLeave?: () => void;
}

export function FlowerStem({
  className,
  color = "#4A7C59",
  height = 200,
  width = 8,
  animationPhase = 0,
  onHover,
  onLeave,
}: FlowerStemProps) {
  const sway = Math.sin((animationPhase || 0) * 0.6) * 3;

  return (
    <svg
      className={cn("w-full h-full", className)}
      viewBox={`0 0 ${100} ${height + 50}`}
      style={{ overflow: "visible" }}
      onMouseEnter={onHover}
      onMouseLeave={onLeave}
    >
      <defs>
        <linearGradient id="stemGrad" x1="0%" y1="0%" x2="0%" y2="100%">
          <stop offset="0%" stopColor={color} />
          <stop offset="50%" stopColor="#3A6B3A" />
          <stop offset="100%" stopColor="#2E5D2E" />
        </linearGradient>
        <filter id="stemShadow" x="-20%" y="-20%" width="140%" height="140%">
          <feGaussianBlur stdDeviation="3" />
          <feOffset dx="2" dy="3" />
          <feComponentTransfer>
            <feFuncA type="table" tableValues="0 0.3" />
          </feComponentTransfer>
          <feBlend in="SourceGraphic" mode="normal" />
        </filter>
      </defs>

      <g
        transform={`translate(50, 0) rotate(${Math.sin((animationPhase || 0) * 0.6) * 3}, 50, 0)`}
        style={{ cursor: "pointer", transformOrigin: "center top" }}
      >
        <path
          d={`M50,0 C50,50 ${60 + Math.sin(0) * 10},${100 + Math.sin(0) * 10} 50,${200} C${40 - Math.sin(0) * 10},${300 - Math.sin(0) * 10} ${60 - Math.sin(0) * 10},${300 - Math.sin(0) * 10} 50,${height}`}
          fill="none"
          stroke="url(#stemGrad)"
          strokeWidth="8"
          strokeLinecap="round"
          strokeLinejoin="round"
          filter="url(#stemShadow)"
        >
          <animate attributeName="d"
            dur="3s"
            repeatCount="indefinite"
            values={
              `M50,0 C50,50 60,100 50,200 C40,300 60,300 50,${height};
               M50,0 C50,50 40,100 50,200 C60,300 40,300 50,${height};
               M50,0 C50,50 60,100 50,200 C40,300 60,300 50,${height}`
            }
          />
        </path>
      </g>
    </svg>
  );
}

export default FlowerStem;
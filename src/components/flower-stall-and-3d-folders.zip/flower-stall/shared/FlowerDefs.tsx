"use client";

import React, { useId } from "react";

interface FlowerDefsProps {
  idPrefix: string;
}

export function FlowerDefs({ idPrefix }: FlowerDefsProps) {
  const petalOuterGrad = useId();
  const petalMiddleGrad = useId();
  const petalInnerGrad = useId();
  const petalBudGrad = useId();
  const centreGrad = useId();
  const centreInnerGrad = useId();
  const stemGrad = useId();
  const leafGrad1 = useId();
  const leafGrad2 = useId();
  const dropShadow = useId();
  const dropShadowHover = useId();
  const innerShadow = useId();
  const petalTexture = useId();

  const petalMainGrad = useId();
  const petalBackGrad = useId();
  const centreHighlightGrad = useId();

  const sprigMainGrad = useId();

  return (
    <defs>
      {/* Rose gradients */}
      <linearGradient id={petalOuterGrad} x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#F5C6D6" />
        <stop offset="50%" stopColor="#E9A8B8" />
        <stop offset="100%" stopColor="#D48A9E" />
      </linearGradient>
      <linearGradient id={petalMiddleGrad} x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#F8D7E3" />
        <stop offset="50%" stopColor="#ECB8C8" />
        <stop offset="100%" stopColor="#E09AA8" />
      </linearGradient>
      <linearGradient id={petalInnerGrad} x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#FCE4EC" />
        <stop offset="50%" stopColor="#F5C6D6" />
        <stop offset="100%" stopColor="#E9A8B8" />
      </linearGradient>
      <linearGradient id={petalBudGrad} x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#FFF0F5" />
        <stop offset="50%" stopColor="#FCE4EC" />
        <stop offset="100%" stopColor="#F5C6D6" />
      </linearGradient>
      <radialGradient id={centreGrad} cx="50%" cy="50%" r="50%">
        <stop offset="0%" stopColor="#FFE082" />
        <stop offset="40%" stopColor="#FFD54F" />
        <stop offset="70%" stopColor="#F9A825" />
        <stop offset="100%" stopColor="#F57F17" />
      </radialGradient>
      <radialGradient id={centreInnerGrad} cx="50%" cy="50%" r="50%">
        <stop offset="0%" stopColor="#FFF9C4" />
        <stop offset="50%" stopColor="#FFF59D" />
        <stop offset="100%" stopColor="#FDD835" />
      </radialGradient>

      {/* Sunflower gradients */}
      <linearGradient id={petalMainGrad} x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#FFEB3B" />
        <stop offset="40%" stopColor="#FFD700" />
        <stop offset="70%" stopColor="#FFC107" />
        <stop offset="100%" stopColor="#FFA000" />
      </linearGradient>
      <linearGradient id={petalBackGrad} x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#FFD600" />
        <stop offset="50%" stopColor="#FFC107" />
        <stop offset="100%" stopColor="#FFA000" />
      </linearGradient>
      <radialGradient id={centreGrad} cx="50%" cy="50%" r="50%">
        <stop offset="0%" stopColor="#3E2723" />
        <stop offset="30%" stopColor="#4E342E" />
        <stop offset="60%" stopColor="#3E2723" />
        <stop offset="100%" stopColor="#212121" />
      </radialGradient>
      <radialGradient id={centreHighlightGrad} cx="50%" cy="50%" r="50%">
        <stop offset="0%" stopColor="#5D4037" />
        <stop offset="50%" stopColor="#4E342E" />
        <stop offset="100%" stopColor="#3E2723" />
      </radialGradient>

      {/* Tulip gradients */}
      <linearGradient id={petalMainGrad} x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#FF69B4" />
        <stop offset="40%" stopColor="#FF69B4" />
        <stop offset="70%" stopColor="#FF1493" />
        <stop offset="100%" stopColor="#C71585" />
      </linearGradient>

      {/* Daisy gradients */}
      <linearGradient id={petalMainGrad} x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#FFFFFF" />
        <stop offset="50%" stopColor="#F8F8F8" />
        <stop offset="100%" stopColor="#F0F0F0" />
      </linearGradient>
      <radialGradient id={centreGrad} cx="50%" cy="50%" r="50%">
        <stop offset="0%" stopColor="#FFEB3B" />
        <stop offset="50%" stopColor="#FFD700" />
        <stop offset="100%" stopColor="#FFD700" />
      </radialGradient>

      {/* Lavender gradients */}
      <linearGradient id={sprigMainGrad} x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#E6E6FA" />
        <stop offset="40%" stopColor="#D8BFD8" />
        <stop offset="70%" stopColor="#DDA0DD" />
        <stop offset="100%" stopColor="#BA55D3" />
      </linearGradient>
      <radialGradient id={centreGrad} cx="50%" cy="50%" r="50%">
        <stop offset="0%" stopColor="#E6E6FA" />
        <stop offset="50%" stopColor="#D8BFD8" />
        <stop offset="100%" stopColor="#BA55D3" />
      </radialGradient>

      {/* Mixed gradients */}
      <linearGradient id={petalMainGrad} x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#FF6B6B" />
        <stop offset="40%" stopColor="#FF6B6B" />
        <stop offset="70%" stopColor="#FF4757" />
        <stop offset="100%" stopColor="#C44569" />
      </linearGradient>

      {/* Shared gradients */}
      <linearGradient id={stemGrad} x1="0%" y1="0%" x2="0%" y2="100%">
        <stop offset="0%" stopColor="#4A7C59" />
        <stop offset="50%" stopColor="#3A6B3A" />
        <stop offset="100%" stopColor="#2E5D2E" />
      </linearGradient>
      <linearGradient id={leafGrad1} x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#6BA571" />
        <stop offset="50%" stopColor="#5A925E" />
        <stop offset="100%" stopColor="#4A7C59" />
      </linearGradient>
      <linearGradient id={leafGrad2} x1="0%" y1="0%" x2="100%" y2="100%">
        <stop offset="0%" stopColor="#7CB87E" />
        <stop offset="50%" stopColor="#6BA571" />
        <stop offset="100%" stopColor="#5A925E" />
      </linearGradient>

      {/* Shared filters */}
      <filter id={dropShadow} x="-20%" y="-20%" width="140%" height="140%">
        <feGaussianBlur stdDeviation="3" />
        <feOffset dx="2" dy="3" />
        <feComponentTransfer>
          <feFuncA type="table" tableValues="0 0.3" />
        </feComponentTransfer>
        <feBlend in="SourceGraphic" mode="normal" />
      </filter>
      <filter id={dropShadowHover} x="-20%" y="-20%" width="140%" height="140%">
        <feGaussianBlur stdDeviation="5" />
        <feOffset dx="3" dy="5" />
        <feComponentTransfer>
          <feFuncA type="table" tableValues="0 0.5" />
        </feComponentTransfer>
        <feBlend in="SourceGraphic" mode="normal" />
      </filter>
      <filter id={innerShadow} x="-20%" y="-20%" width="140%" height="140%">
        <feOffset dx="0" dy="1" />
        <feGaussianBlur stdDeviation="2" />
        <feComponentTransfer>
          <feFuncA type="table" tableValues="0 0.2" />
        </feComponentTransfer>
        <feBlend in="SourceGraphic" mode="normal" />
      </filter>

      {/* Petal texture pattern */}
      <pattern id={petalTexture} patternUnits="userSpaceOnUse" width="4" height="4">
        <circle cx="2" cy="2" r="0.5" fill="rgba(255,255,255,0.1)" />
      </pattern>
    </defs>
  );
}

// Export ID getters for use in bouquet components
export function getFlowerIds(idPrefix: string) {
  return {
    petalOuterGrad: `${idPrefix}-petalOuterGrad`,
    petalMiddleGrad: `${idPrefix}-petalMiddleGrad`,
    petalInnerGrad: `${idPrefix}-petalInnerGrad`,
    petalBudGrad: `${idPrefix}-petalBudGrad`,
    centreGrad: `${idPrefix}-centreGrad`,
    centreInnerGrad: `${idPrefix}-centreInnerGrad`,
    stemGrad: `${idPrefix}-stemGrad`,
    leafGrad1: `${idPrefix}-leafGrad1`,
    leafGrad2: `${idPrefix}-leafGrad2`,
    dropShadow: `${idPrefix}-dropShadow`,
    dropShadowHover: `${idPrefix}-dropShadowHover`,
    innerShadow: `${idPrefix}-innerShadow`,
    petalTexture: `${idPrefix}-petalTexture`,
    petalMainGrad: `${idPrefix}-petalMainGrad`,
    petalBackGrad: `${idPrefix}-petalBackGrad`,
    centreHighlightGrad: `${idPrefix}-centreHighlightGrad`,
    sprigMainGrad: `${idPrefix}-sprigMainGrad`,
  };
}
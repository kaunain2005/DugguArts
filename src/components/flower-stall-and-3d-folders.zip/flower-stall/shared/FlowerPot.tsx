"use client";

import React from "react";
import { cn } from "@/lib/utils";

interface FlowerPotProps {
  className?: string;
  type: 'terracotta' | 'ceramic' | 'paper' | 'fabric' | 'wicker';
  color: string;
  gradient: string;
  size?: number;
  onClick?: () => void;
}

const potGradients: Record<string, string> = {
  terracotta: "linear-gradient(135deg, #E6A06B 0%, #B96843 100%)",
  ceramic: "linear-gradient(135deg, #F5B6C9 0%, #D77D9D 100%)",
  paper: "linear-gradient(135deg, #FFF0F5 0%, #FCE4EC 100%)",
  fabric: "linear-gradient(135deg, #E6A06B 0%, #D77D9D 100%)",
  wicker: "linear-gradient(135deg, #E6A06B 0%, #B96843 100%)",
};

export function FlowerPot({
  className,
  type = 'terracotta',
  color,
  gradient,
  size = 100,
  onClick,
}: FlowerPotProps) {
  const scale = size / 100;
  const gradientId = `pot-${type}-${color.replace('#', '')}`;

  return (
    <svg
      className={cn("w-full h-full", className)}
      viewBox="0 0 100 100"
      width={size}
      height={size}
      style={{ overflow: "visible" }}
    >
      <defs>
        <linearGradient id={`${gradientId}-grad`} x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor={color} />
          <stop offset="100%" stopColor={gradient || potGradients[type]?.split(" ")[1] || color} />
        </linearGradient>
      </defs>

      {/* Pot body */}
      <g>
        <path
          d="M20 40 L10 55 L90 55 L80 40 Z"
          fill={`url(#${gradientId}-grad)`}
          stroke="#8D6138"
          strokeWidth="2"
        />
        {/* Pot rim */}
        <path
          d="M10 40 L80 40"
          fill="none"
          stroke="#8D6138"
          strokeWidth="3"
          strokeLinecap="round"
        />
        {/* Pot base */}
        <ellipse
          cx="50"
          cy="95"
          rx="35"
          ry="5"
          fill="#8D6138"
          opacity="0.3"
        />
      </g>
    </svg>
  );
}

export default FlowerPot;
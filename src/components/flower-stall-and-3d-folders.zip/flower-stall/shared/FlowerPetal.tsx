"use client";

import React from "react";
import { cn } from "@/lib/utils";

interface FlowerPetalProps {
  className?: string;
  layer: "outer" | "middle" | "inner" | "bud";
  path: string;
  gradient: string;
  angle: number;
  distance: number;
  scale: number;
  separation: number;
  exploded: boolean;
  hovered: boolean;
  active: boolean;
  id: string;
  layerName: string;
  index: number;
  onHover?: () => void;
  onLeave?: () => void;
}

export function FlowerPetal({
  layer,
  path,
  gradient,
  angle,
  distance,
  scale,
  separation,
  exploded,
  hovered,
  active,
  id,
  layerName,
  index,
  onHover,
  onLeave,
}: {
  layer: string;
  path: string;
  gradient: string;
  angle: number;
  distance: number;
  scale: number;
  separation: number;
  exploded: boolean;
  hovered: boolean;
  active: boolean;
  id: string;
  layerName: string;
  index: number;
  onHover?: () => void;
  onLeave?: () => void;
}) {
  const separationAmount = exploded ? distance : 0;
  const isHovered = hovered;
  const isExplodedActive = exploded && layer !== "bud";

  const transform = `
    translate(250 215)
    rotate(${angle})
    translate(0 ${-separation})
    scale(${scale})
  `;

  return (
    <g
      id={`petal-${id}`}
      transform={`translate(250 215) rotate(${angle}) translate(0 ${-separation}) scale(${scale})`}
      style={{
        transformBox: "view-box",
        transition: "transform 850ms cubic-bezier(.2,.75,.25,1)",
        cursor: "pointer",
      }}
      onPointerEnter={onHover}
      onPointerLeave={onLeave}
    >
      <g
        style={{
          filter: active
            ? "url(#hover-shadow)"
            : "url(#shadow)",
          transform: active ? "scale(1.04)" : "scale(1)",
          transformOrigin: "center",
          transition: "transform 350ms ease, filter 350ms ease",
        }}
      >
        <path
          d={path}
          fill={`url(#${gradient})`}
          stroke="#C96C8C"
          strokeOpacity=".25"
          strokeWidth="1.2"
        />

        {/* Petal highlight */}
        <path
          d="M0 -5 C-8 -28 -10 -60 0 -94"
          fill="none"
          stroke="#FFF4F7"
          strokeWidth="2.5"
          strokeLinecap="round"
          opacity=".42"
        />

        {/* Soft inner shading */}
        <path
          d="M-20 -23 Q-29 -53 -14 -76"
          fill="none"
          stroke="#62a94f"
          strokeWidth="2"
          strokeLinecap="round"
          opacity=".14"
        />
      </g>
    </g>
  );
}

export default FlowerPetal;
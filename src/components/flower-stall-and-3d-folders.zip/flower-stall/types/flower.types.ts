export interface FlowerArrangement {
  id: string;
  name: string;
  slug: string;
  description: string;
  flowers: Flower[];
  container: FlowerContainer;
  wrapping: BouquetWrapper;
  featured: boolean;
  position: FlowerPosition;
}

export interface Flower {
  type: 'rose' | 'sunflower' | 'tulip' | 'daisy' | 'lavender' | 'mixed';
  count: number;
  colors: string[];
  stemColor: string;
  leafColor: string;
}

export interface FlowerContainer {
  type: 'pot' | 'vase' | 'wrapping' | 'basket';
  color: string;
  material: 'terracotta' | 'ceramic' | 'paper' | 'fabric' | 'wicker';
  gradient: string;
}

export interface BouquetWrapper {
  type: 'paper' | 'fabric' | 'cellophane' | 'none';
  color: string;
  gradient: string;
}

export interface FlowerPosition {
  row: 1 | 2;
  column: 1 | 2 | 3;
  x: number;
  y: number;
  rotation: number;
  scale: number;
}

export interface FlowerArrangementProps {
  arrangement: FlowerArrangement;
  isHovered: boolean;
  isFocused: boolean;
  onHover: (id: string) => void;
  onLeave: () => void;
  onClick: (arrangement: FlowerArrangement) => void;
  exploded?: boolean;
  animationPhase?: number;
}

export interface FlowerStallProps {
  className?: string;
  onArrangementClick?: (arrangement: FlowerArrangement) => void;
  onArrangementHover?: (id: string) => void;
  onArrangementLeave?: () => void;
}

export interface FocusedFlowerProps {
  arrangement: FlowerArrangement;
  onClose: () => void;
  onBackdropClick: () => void;
}

export type FlowerType = 'rose' | 'sunflower' | 'tulip' | 'daisy' | 'lavender' | 'mixed';

export interface FlowerComponentProps {
  className?: string;
  size?: number;
  exploded?: boolean;
  hoveredPart?: string | null;
  animationPhase?: number;
  onPetalHover?: (id: string) => void;
  onPetalLeave?: () => void;
  onCentreHover?: () => void;
  onCentreLeave?: () => void;
  onLeafHover?: (index: number) => void;
  onLeafLeave?: () => void;
  onStemHover?: () => void;
  onStemLeave?: () => void;
}

export interface FlowerFocusedViewProps {
  arrangement: FlowerArrangement;
  onClose: () => void;
  onBackdropClick: () => void;
}

export interface FlowerStallProps {
  className?: string;
  onArrangementClick?: (arrangement: FlowerArrangement) => void;
  onArrangementHover?: (id: string) => void;
  onArrangementLeave?: () => void;
}

export interface FlowerFocusedViewProps {
  arrangement: FlowerArrangement;
  onClose: () => void;
  onBackdropClick: () => void;
}